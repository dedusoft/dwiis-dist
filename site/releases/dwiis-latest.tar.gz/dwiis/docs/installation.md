# Installation Guide

## Prerequisites

- Ubuntu 22.04, 24.04, or 26.04 LTS
- Sudo access
- Internet connectivity (or pre-populated offline cache)
- Git access to the platform repository

## Bootstrap from curl

The recommended production flow verifies integrity before execution:

```bash
curl -fsSL https://dwiis.dedusoft.com/install.sh -o /tmp/dwiis-install.sh
curl -fsSL https://dwiis.dedusoft.com/install.sh.sha256 -o /tmp/dwiis-install.sh.sha256
sha256sum -c /tmp/dwiis-install.sh.sha256
bash /tmp/dwiis-install.sh --profile backend
```

For development, pipe directly (less secure):

```bash
curl -fsSL https://dwiis.dedusoft.com/install.sh | bash -s -- --profile full
```

## Bootstrap steps

1. Detect OS (Ubuntu LTS only)
2. Check connectivity (or use existing `/opt/dwiis`)
3. Install prerequisites (`git`, `curl`, `ansible`, `python3`)
4. Clone or update platform to `/opt/dwiis`
5. Install `dwiis` CLI to `/usr/local/bin`
6. Run `scripts/install.sh` with selected profile

## Install orchestrator steps

The orchestrator (`scripts/install.sh`) runs:

1. `bootstrap_prereqs` — apt packages for Ansible
2. `populate_cache` — download artifacts from `configs/cache-manifest.txt`
3. `ansible_provision` — profile-driven Ansible playbook
4. `verify` — component verification report

Each step is checkpointed. Re-run safely after interruption:

```bash
dwiis install --profile backend
```

## Resume after failure

State is stored in `/var/lib/dwiis/state/steps.state`. Completed steps are skipped automatically.

To force a full re-run:

```bash
dwiis install --profile backend --reset-state
```

## Offline installation

1. On a connected machine, populate the cache manifest with internal mirror URLs
2. Copy `/var/lib/dwiis/cache/` to the target machine
3. Set `DWIIS_INTERNAL_MIRROR` in `/etc/dwiis/platform.env`
4. Run install — apt and artifacts use cache first

## Post-install

```bash
dwiis verify
dwiis status
```

Log out and back in after install so Docker group membership takes effect.

Database tools (PostgreSQL, MySQL, MongoDB, Redis) run in Docker. Confirm with:

```bash
sudo systemctl status docker dwiis-dev-services
psql -c 'SELECT 1'
```
