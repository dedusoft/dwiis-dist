# Docker Dev Services

## Overview

Database and other port-based development tools run as Docker containers, not native Ubuntu packages. This keeps workstations consistent and avoids port conflicts with system services.

**Install order:**

1. Docker Engine installed and `docker.service` started
2. `docker_services` Ansible role deploys Compose stack
3. `dwiis-dev-services.service` enabled for boot persistence
4. Host CLI wrappers installed to `/usr/local/bin`

## Services by profile

| Profile | Services |
|---------|----------|
| `backend` | postgres, mysql, mongodb, redis, adminer |
| `devops` | postgres, redis, adminer |
| `full` | postgres, mysql, mongodb, redis, adminer |
| `frontend` | Docker only (no databases) |

## Files

| Path | Purpose |
|------|---------|
| `/etc/dwiis/docker/dev-services.compose.yml` | Compose stack |
| `/etc/dwiis/docker/dev.env` | Dev credentials |
| `/var/lib/dwiis/docker-data/` | Persistent volumes |
| `~/.config/dwiis/docker/connections.env` | GUI connection hints |

## CLI wrappers

Wrappers ensure the dev stack is running, then exec into the container:

```bash
psql -c 'SELECT 1'
mysql -e 'SELECT 1'
mongosh --eval 'db.runCommand({ ping: 1 })'
redis-cli ping
newman run collection.json   # via postman/newman Docker image
```

## Managing services

```bash
sudo systemctl start dwiis-dev-services
sudo systemctl stop dwiis-dev-services
docker compose -f /etc/dwiis/docker/dev-services.compose.yml ps
```

## GUI clients

DBeaver and Adminer connect to `127.0.0.1` on the ports above. See `connections.env` for credentials.

## Customization

Override credentials in `/etc/dwiis/docker/dev.env`, then:

```bash
sudo systemctl restart dwiis-dev-services
```

Add services in `ansible/roles/docker_services/defaults/main.yml` and re-run install.
