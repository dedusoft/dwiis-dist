# Versioning & Releases

DWIIS is **proprietary software by Dedusoft**. Source code lives in the private
repository `dedusoft/dwiis`. Public users install and update from **release
artifacts**: versioned tarballs with SHA-256 checksums, published by a
deployment environment (see [deployment/](deployment/README.md)).

## How distribution works

| Audience | Install | Update | Source access |
|---|---|---|---|
| **Public users** | `curl -fsSL https://dwiis.dedusoft.com/install.sh \| bash` | `dwiis self-update` (artifact mode) | None, tarball only |
| **Dedusoft engineers** | Git clone, or bootstrap with `--mode git` | `dwiis self-update` (git mode) | Private repository |

| Config file | Used on |
|---|---|
| `configs/platform.env.public` | Public machines (artifact mode). The build writes the environment's artifact URL into it. |
| `configs/platform.env` | Engineer workstations (git mode, private repo URL) |

Where public machines download from:

| Installed with | `DWIIS_ARTIFACT_BASE_URL` |
|---|---|
| v1.2.0 or later, GitHub environment | `https://github.com/dedusoft/dwiis-dist/releases/latest/download` |
| Before v1.2.0, or the AWS EC2 environment | `https://dwiis.dedusoft.com/releases` (still served by every environment) |

---

## Version and changelog

- **`VERSION`** at the repository root holds the version (`MAJOR.MINOR.PATCH`).
  - `patch`: fixes, no behaviour change for users
  - `minor`: new tools, profiles or features, backward compatible
  - `major`: breaking changes (removed profiles, changed install paths, …)
- **`CHANGELOG.md`** follows [Keep a Changelog](https://keepachangelog.com/).
  Add entries under `## [Unreleased]` in the same pull request as the change.
  The Release workflow moves them under the new version, and they become the
  release notes on GitHub. Without entries, the notes list commit subjects
  since the previous tag.
- Each release has an annotated tag `vX.Y.Z` on the commit it was built from.

---

## Cutting a release (GitHub Actions)

1. Merge your changes, with changelog entries, to `main`.
2. **Actions → Release → Run workflow** → choose `patch`, `minor` or `major`.

The workflow bumps `VERSION`, updates `CHANGELOG.md`, commits
`chore(release): vX.Y.Z`, tags it, builds, creates GitHub Releases in both
repositories, deploys the website and checks that `dwiis.dedusoft.com` serves the
new version. Details: [deployment/github.md](deployment/github.md#3-publishing-a-release).

You can also bump and tag locally, then push the tag:

```bash
./scripts/bump-version.sh patch
./scripts/changelog-release.sh "$(cat VERSION)"
git commit -am "chore(release): v$(cat VERSION)"
git tag -a "v$(cat VERSION)" -m "DWIIS v$(cat VERSION)"
git push origin main "v$(cat VERSION)"
```

### Building locally

```bash
./scripts/build-release.sh --out dist          # AWS layout (default URLs)
./scripts/build-release.sh --out dist \
  --artifact-base-url https://github.com/dedusoft/dwiis-dist/releases/latest/download
./scripts/release-notes.sh "$(cat VERSION)" --audience public --release-dir dist/release
```

Builds are reproducible: the same commit always gives the same checksums.
Internal paths (`knowledge/`, `deploy/`, deployment docs, `.github/`) are not
included in the tarball.

---

## Rollback

- **GitHub environment:** **Actions → Rollback → Run workflow** with the version
  to promote. See [deployment/github.md](deployment/github.md#5-rollback).
- **AWS EC2:** check out the older tag on the server and run
  `./deploy/scripts/sync-bootstrap.sh`. See
  [deployment/aws-ec2.md](deployment/aws-ec2.md#11-rollback).

Workstations then run `dwiis self-update`.

---

## Internal development (private Git)

```bash
git clone git@github.com:dedusoft/dwiis.git
cd dwiis
sudo mkdir -p /etc/dwiis
sudo cp configs/platform.env /etc/dwiis/platform.env
sudo install -m 755 scripts/dwiis /usr/local/bin/dwiis
dwiis install --profile full
```

With `DWIIS_DISTRIBUTION_MODE=git`, `dwiis self-update` pulls from Git instead of
downloading a release. To test the bootstrap in git mode:

```bash
bash bootstrap/install.sh --mode git --repo git@github.com:dedusoft/dwiis.git --profile minimal
```

---

## Release checklist

- [ ] Changelog entries under `## [Unreleased]`
- [ ] CI green on `main`
- [ ] Tested on a clean Ubuntu 22.04 / 24.04 / 26.04 machine
- [ ] Release workflow run, all jobs green (including **Verify dwiis.dedusoft.com**)
- [ ] Team told to run `dwiis self-update`

Supported systems: Ubuntu LTS **22.04**, **24.04** and **26.04**.
