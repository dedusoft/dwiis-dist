# Security Model

## Package integrity

- APT packages from official Ubuntu, Docker, Microsoft, and Google repositories with GPG signing
- Downloaded artifacts support SHA-256 verification via `scripts/lib/common.sh`
- Bootstrap script supports checksum verification before execution

## Bootstrap safety

Avoid piping unverified scripts to bash in production. Recommended flow:

```bash
curl -fsSL .../install.sh -o install.sh
sha256sum -c install.sh.sha256
bash install.sh
```

## Configuration protection

- SSH config: `PermitRootLogin no`; password auth disabled when SSH keys exist
- Sudo: platform does not weaken sudo requirements
- User configs: backed up before overwrite (`scripts/lib/backup.sh`)
- SSH keys and `authorized_keys` are never modified by the platform

## Secrets

- Do not commit secrets to this repository
- Use `/etc/dwiis/local-overrides.env` for environment-specific values
- Company CA certs go in `configs/certificates/*.crt` (internal repo only)

## Hardening scope

The platform applies sensible defaults without locking developers out:

- `umask 022` via `/etc/profile.d/dwiis-umask.sh`
- `unattended-upgrades` installed
- Official package sources only in Ansible roles

## Audit and compliance

```bash
dwiis audit
```

Detects:

- Missing required packages for active profile
- Disabled or stopped services (e.g. Docker)
- Version below approved minimums
- Config file hash drift (when checksums are published)

## Reporting security issues

Report platform security concerns to your internal platform team.
