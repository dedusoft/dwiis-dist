# Operations Runbook

## Daily commands

```bash
dwiis status          # Profile, completed steps, report paths
dwiis verify          # Full component check
dwiis audit           # Drift vs company standard
dwiis audit --remediate  # Fix missing packages/services where possible
```

## Updating the platform

```bash
dwiis self-update
dwiis install --profile $(cat /var/lib/dwiis/state/profile)
```

Local overrides in `/etc/dwiis/local-overrides.env` are preserved.

## Rollback

Config files are backed up before modification to `/var/lib/dwiis/backups/`.

```bash
# Restore files from last failed step
dwiis rollback --last-failed

# Restore files from a specific step
dwiis rollback --step ansible_provision
```

Rollback restores configuration files only. Installed packages are not automatically removed.

## Logs

```bash
sudo tail -f /var/log/dwiis/latest.log
ls -lt /var/log/dwiis/
```

## Reports

```bash
cat /var/lib/dwiis/reports/latest-verify.txt
cat /var/lib/dwiis/reports/latest-audit.txt
```

## Troubleshooting

| Symptom | Action |
|---------|--------|
| apt lock errors | Re-run install — retry logic handles transient locks |
| Step stuck after failure | Check logs; run `rollback`; `install --reset-state` if needed |
| Docker permission denied | Log out/in after install; confirm user in `docker` group |
| Drift after manual changes | `audit --remediate` or re-run `install` |
| Wrong profile | `install --profile <name> --reset-state` |

## Internal mirror setup

Edit `/etc/dwiis/platform.env`:

```bash
DWIIS_INTERNAL_MIRROR="https://apt-mirror.dedusoft.com/ubuntu"
DWIIS_REPO_URL="https://git.dedusoft.com/platform/dwiis.git"
```

Populate `configs/cache-manifest.txt` with cached `.deb` and artifact URLs for air-gapped installs.

## Troubleshooting provisioning

### Ansible role not found

Point Ansible at the platform configuration and re-run:

```bash
export ANSIBLE_CONFIG=/opt/dwiis/ansible/ansible.cfg
export ANSIBLE_ROLES_PATH=/opt/dwiis/ansible/roles
ls /opt/dwiis/ansible/roles/common
dwiis install --profile minimal
```

### Re-run Ansible after a platform fix

If `ansible_provision` completed before a fix was released, clear that step and
install again:

```bash
sudo sed -i '/^done:ansible_provision$/d' /var/lib/dwiis/state/steps.state
dwiis install --profile minimal
```

### Internal git mode cannot reach the repository

Confirm your SSH key has access to the private `dedusoft/dwiis` repository, then:

```bash
bash bootstrap/install.sh --mode git --repo git@github.com:dedusoft/dwiis.git
```
