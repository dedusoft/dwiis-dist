# Extending Profiles and Tools

## Add a new profile

1. Create `configs/profiles/<name>.yaml` based on an existing profile
2. List `tools`, `packages.apt`, and `roles` as needed
3. Add profile name to validation in `ansible/playbooks/site.yml`
4. Add Ansible role conditionals for profile-specific roles

Example:

```yaml
name: data
description: Data engineering toolchain
extends: base

roles:
  - common
  - shell
  - pyenv
  - docker

tools:
  - python
  - pyenv
  - docker
```

## Add a Docker-backed dev service

1. Add the service to `ansible/roles/docker_services/defaults/main.yml` under `dwiis_docker_images`, `dwiis_docker_cli_wrappers`, and profile lists in `dwiis_docker_services_by_profile`
2. Extend `ansible/roles/docker_services/templates/dev-services.compose.yml.j2`
3. Add verification in `scripts/verify.sh` and `scripts/audit.sh`
4. Re-run `dwiis install`

Database tools must run in Docker — do not add native `postgresql-client`, `mysql-client`, or `redis-tools` apt packages.

## Add a new Ansible role

```bash
mkdir -p ansible/roles/my_tool/tasks
```

Create `ansible/roles/my_tool/tasks/main.yml` with idempotent tasks (`state: present`, `creates:` guards).

Wire the role in `ansible/playbooks/site.yml`:

```yaml
- role: my_tool
  when: dwiis_active_profile in ['data', 'full']
```

## Add verification checks

Edit `scripts/verify.sh` — add a case in `dwiis_verify_profile_tools` for your tool name.

## Add audit checks

Edit `scripts/audit.sh` — extend `dwiis_audit_packages`, `dwiis_audit_services`, or `dwiis_audit_versions`.

## Offline cache entries

Add lines to `configs/cache-manifest.txt`:

```text
artifact-name|https://mirror.dedusoft.com/path/file.deb|sha256hex
```

## Approved versions

Update `configs/platform.env`:

```bash
DWIIS_NODE_VERSION="22"
DWIIS_GIT_MIN_VERSION="2.34"
```

Verification and audit scripts read these values.
