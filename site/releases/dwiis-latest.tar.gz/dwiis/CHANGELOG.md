# Changelog

All notable changes to DWIIS are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project uses
[Semantic Versioning](https://semver.org/).

Release notes on GitHub are generated from the matching section of this file,
so add an entry under `## [Unreleased]` with every user-visible change and
rename it when you cut a release.

## [Unreleased]

## [1.2.0] - 2026-10-19

### Added
- GitHub deployment environment: the website and installer are served by GitHub
  Pages on `dwiis.dedusoft.com`, and versioned release tarballs are published as
  GitHub Releases in the public `dedusoft/dwiis-dist` repository.
- Automated release pipeline (`Release` workflow): bump the version, tag, build,
  publish GitHub Releases and deploy, from a single button in GitHub Actions.
- `Rollback` workflow to promote any previous release back to latest.
- `CI` workflow: ShellCheck, syntax checks and a reproducible-build check on
  every push and pull request.
- `scripts/build-release.sh`: one reproducible build shared by every deployment
  environment, and `scripts/release-notes.sh` for release notes.
- Per-environment deployment guides under `docs/deployment/`.
- `SHA256SUMS` file attached to every release.

### Changed
- Public installs now download release tarballs from GitHub Releases. Machines
  installed earlier keep updating through `https://dwiis.dedusoft.com/releases/`,
  which remains available.
- The AWS EC2 `sync-bootstrap.sh` script now uses the shared build; its output
  and Nginx layout are unchanged.
- Internal material (`knowledge/`, `deploy/`, deployment docs) is no longer
  shipped in public release tarballs.

## [1.1.9] - 2026-07-02

- Fix post install verification step after ansible_provision completed

## [1.1.8] - 2026-07-02

- Fix verification step and false docker service status not running for ui-tools
- Convert project name to lowercase

## [1.1.7] - 2026-07-01

- Fix sdkman installation to use shell block as a Jinja template

## [1.1.6] - 2026-07-01

- Add version-aware provisioning
- Remove slack and add thunderbird and signal as communication tools

## [1.1.5] - 2026-07-01

- Fix UI tools to check whether an application exists before installing, and fix a broken apt command

## [1.1.4] - 2026-06-26

- Fix conflicting VS Code apt Signed-By key paths

## [1.1.3] - 2026-06-19

- Fix PHP and VS Code apt setup for Ubuntu 24.04+

## [1.1.2] - 2026-06-19

- Fix nvm install when npm global dirs or npmrc prefix are missing

## [1.1.1] - 2026-06-19

- Auto-select free host ports for Docker dev services

## [1.1.0] - 2026-06-19

- Fix profile upgrades and split bootstrap from profile install

## [1.0.8] - 2026-06-19

- Ensure target user config directories exist before Ansible deploys

## [1.0.7] - 2026-06-18

- Fix Ansible provisioning when OpenSSH server is not installed
- Fix Ansible stdout callback removed in community.general 12.0

## [1.0.6] - 2026-06-18

- Fix unbound DEWIIS_PROFILE typo in install.sh Ansible step.

## [1.0.5] - 2026-06-18

- Fix Ansible role discovery by setting ANSIBLE_CONFIG and ANSIBLE_ROLES_PATH.
- Fix double-source errors in lib scripts and show version on landing page footer.
- Fix install.sh resolving repo root to /opt instead of /opt/dwiis.

## [1.0.4] - 2026-06-18

- Fix double-source errors in lib scripts and show version on landing page footer.

## [1.0.3] - 2026-06-18

- Fix install.sh resolving repo root to /opt instead of /opt/dwiis.

## [1.0.2] - 2026-06-18

- Rollback patch accepting Ubuntu 26.04
- Document the proprietary distribution model and production deployment; improve `sync-bootstrap.sh` artifact publishing
- Added ubuntu 26.04 LTS to list of supported tools
- Refactor checksum calculation in sync-bootstrap.sh for install.sh and update README.md with production deployment documentation link.
- Update README.md
- Rebrand to DWIIS; add Docker-backed dev services and production bootstrap hosting
- Run database and port-based dev tools in Docker with host CLI wrappers.
- Initial commit
