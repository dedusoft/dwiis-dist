#!/usr/bin/env bash
# shellcheck shell=bash
# Move the "## [Unreleased]" entries of CHANGELOG.md under a new version heading.
#
# Usage: changelog-release.sh <X.Y.Z> [YYYY-MM-DD]
#
# No-op when the Unreleased section is empty or the version already has a section
# (release notes then fall back to commit subjects).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILE="$(cd "${SCRIPT_DIR}/.." && pwd)/CHANGELOG.md"
VERSION="${1:-}"
DATE="${2:-$(date -u +%F)}"

[[ "${VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "usage: changelog-release.sh <X.Y.Z> [date]" >&2; exit 1; }
[[ -f "${FILE}" ]] || { echo "CHANGELOG.md not found — skipping"; exit 0; }

if grep -q "^## \[${VERSION}\]" "${FILE}"; then
  echo "CHANGELOG.md already has a ${VERSION} section"
  exit 0
fi

pending="$(awk '/^## \[Unreleased\]/{f=1;next} f&&/^## \[/{exit} f' "${FILE}" | grep -c '[^[:space:]]' || true)"
if [[ "${pending}" -eq 0 ]]; then
  echo "No Unreleased entries — CHANGELOG.md unchanged"
  exit 0
fi

awk -v v="${VERSION}" -v d="${DATE}" '
  /^## \[Unreleased\]/ { print; print ""; print "## [" v "] - " d; next }
  { print }
' "${FILE}" > "${FILE}.tmp" && mv "${FILE}.tmp" "${FILE}"
echo "CHANGELOG.md: Unreleased entries moved to ${VERSION}"
