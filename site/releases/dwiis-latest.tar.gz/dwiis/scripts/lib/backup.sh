#!/usr/bin/env bash
# shellcheck shell=bash
# Config backup and rollback support.

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

DWIIS_ROLLBACK_MANIFEST="${DWIIS_BACKUP_DIR}/rollback.manifest"

dwiis_backup_file() {
  local src="$1"
  local step="${2:-manual}"

  if [[ ! -e "${src}" ]]; then
    dwiis_log_debug "No file to backup: ${src}"
    return 0
  fi

  local ts dest_name dest
  ts="$(date +%Y%m%d-%H%M%S)"
  dest_name="$(echo "${src}" | tr '/' '_')"
  dest="${DWIIS_BACKUP_DIR}/${step}-${dest_name}-${ts}"

  sudo cp -a "${src}" "${dest}"
  echo "${step}|${src}|${dest}" | sudo tee -a "${DWIIS_ROLLBACK_MANIFEST}" >/dev/null
  dwiis_log_info "Backed up ${src} -> ${dest}"
}

dwiis_backup_before_write() {
  local target="$1"
  local step="$2"
  if [[ -f "${target}" ]]; then
    dwiis_backup_file "${target}" "${step}"
  fi
}

dwiis_rollback_step() {
  local step="${1:-}"

  if [[ ! -f "${DWIIS_ROLLBACK_MANIFEST}" ]]; then
    dwiis_log_warn "No rollback manifest found"
    return 0
  fi

  local restored=0
  while IFS='|' read -r manifest_step src backup; do
    if [[ -z "${step}" || "${manifest_step}" == "${step}" ]]; then
      if [[ -f "${backup}" ]]; then
        sudo cp -a "${backup}" "${src}"
        dwiis_log_info "Restored ${src} from ${backup}"
        restored=$((restored + 1))
      fi
    fi
  done < <(sudo cat "${DWIIS_ROLLBACK_MANIFEST}")

  if [[ "${restored}" -eq 0 ]]; then
    dwiis_log_warn "No backups restored for step: ${step:-all}"
  else
    dwiis_log_info "Rollback complete: ${restored} file(s) restored"
  fi
}

dwiis_rollback_last_failed_step() {
  local failed
  failed="$(grep '^failed:' "${DWIIS_STATE_DIR}/steps.state" 2>/dev/null | tail -1 | cut -d: -f2 || true)"
  if [[ -n "${failed}" ]]; then
    dwiis_rollback_step "${failed}"
  else
    dwiis_rollback_step ""
  fi
}
