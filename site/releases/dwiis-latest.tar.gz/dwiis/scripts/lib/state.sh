#!/usr/bin/env bash
# shellcheck shell=bash
# Checkpoint/resume state management.

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

DWIIS_STATE_FILE="${DWIIS_STATE_DIR}/steps.state"
DWIIS_PROFILE_FILE="${DWIIS_STATE_DIR}/profile"
DWIIS_PROVISIONED_PROFILE_FILE="${DWIIS_STATE_DIR}/provisioned-profile"
DWIIS_PROVISIONED_VERSION_FILE="${DWIIS_STATE_DIR}/provisioned-version"

dwiis_state_init() {
  dwiis_ensure_dirs
  if [[ ! -f "${DWIIS_STATE_FILE}" ]]; then
    sudo touch "${DWIIS_STATE_FILE}"
    sudo chmod 644 "${DWIIS_STATE_FILE}"
  fi
}

dwiis_step_completed() {
  local step="$1"
  dwiis_state_init
  grep -qxF "done:${step}" "${DWIIS_STATE_FILE}" 2>/dev/null
}

dwiis_step_mark_done() {
  local step="$1"
  dwiis_state_init
  if ! dwiis_step_completed "${step}"; then
    echo "done:${step}" | sudo tee -a "${DWIIS_STATE_FILE}" >/dev/null
    dwiis_log_info "Step completed: ${step}"
  fi
}

dwiis_step_mark_failed() {
  local step="$1"
  dwiis_state_init
  echo "failed:${step}:$(date -Iseconds)" | sudo tee -a "${DWIIS_STATE_FILE}" >/dev/null
  dwiis_log_error "Step failed: ${step}"
}

dwiis_step_reset() {
  local step="$1"
  dwiis_state_init
  sudo sed -i "/^done:${step}$/d" "${DWIIS_STATE_FILE}" 2>/dev/null || true
  sudo sed -i "/^failed:${step}:/d" "${DWIIS_STATE_FILE}" 2>/dev/null || true
}

dwiis_state_reset_all() {
  dwiis_state_init
  sudo truncate -s 0 "${DWIIS_STATE_FILE}"
  dwiis_log_info "All step state cleared"
}

dwiis_set_profile() {
  local profile="$1"
  echo "${profile}" | sudo tee "${DWIIS_PROFILE_FILE}" >/dev/null
}

dwiis_get_profile() {
  if [[ -f "${DWIIS_PROFILE_FILE}" ]]; then
    cat "${DWIIS_PROFILE_FILE}"
  else
    echo "full"
  fi
}

dwiis_get_provisioned_profile() {
  if [[ -f "${DWIIS_PROVISIONED_PROFILE_FILE}" ]]; then
    cat "${DWIIS_PROVISIONED_PROFILE_FILE}"
  fi
}

dwiis_get_effective_provisioned_profile() {
  local profile
  profile="$(dwiis_get_provisioned_profile)"
  if [[ -n "${profile}" ]]; then
    echo "${profile}"
  elif [[ -f "${DWIIS_PROFILE_FILE}" ]]; then
    cat "${DWIIS_PROFILE_FILE}"
  fi
}

dwiis_set_provisioned_profile() {
  local profile="$1"
  echo "${profile}" | sudo tee "${DWIIS_PROVISIONED_PROFILE_FILE}" >/dev/null
}

dwiis_get_provisioned_version() {
  if [[ -f "${DWIIS_PROVISIONED_VERSION_FILE}" ]]; then
    cat "${DWIIS_PROVISIONED_VERSION_FILE}"
  fi
}

dwiis_set_provisioned_version() {
  local version="$1"
  echo "${version}" | sudo tee "${DWIIS_PROVISIONED_VERSION_FILE}" >/dev/null
}

dwiis_invalidate_provision_if_needed() {
  local requested_profile="$1"
  local current_version="$2"
  local provisioned_profile provisioned_version reason=""

  provisioned_profile="$(dwiis_get_effective_provisioned_profile)"
  provisioned_version="$(dwiis_get_provisioned_version)"

  if [[ -n "${provisioned_profile}" && "${provisioned_profile}" != "${requested_profile}" ]]; then
    reason="profile changed (${provisioned_profile} -> ${requested_profile})"
  elif [[ -n "${provisioned_version}" && "${provisioned_version}" != "${current_version}" ]]; then
    reason="platform updated (${provisioned_version} -> ${current_version})"
  fi

  if [[ -n "${reason}" ]]; then
    dwiis_log_info "Re-provisioning required: ${reason}"
    dwiis_step_reset "ansible_provision"
    dwiis_step_reset "verify"
    return 0
  fi

  if dwiis_step_completed "ansible_provision" && [[ ! -f "${DWIIS_PROVISIONED_PROFILE_FILE}" ]]; then
    if [[ -n "${provisioned_profile}" && "${provisioned_profile}" == "${requested_profile}" ]]; then
      dwiis_log_info "Migrating install state for profile ${requested_profile}"
      dwiis_set_provisioned_profile "${requested_profile}"
      dwiis_set_provisioned_version "${current_version}"
    else
      dwiis_log_info "Re-provisioning required: profile ${requested_profile} not yet provisioned"
      dwiis_step_reset "ansible_provision"
      dwiis_step_reset "verify"
    fi
  fi
}

dwiis_list_completed_steps() {
  dwiis_state_init
  grep '^done:' "${DWIIS_STATE_FILE}" 2>/dev/null | sed 's/^done://' || true
}
