#!/usr/bin/env bash
# shellcheck shell=bash
# Shared helpers for Docker-backed dev services.

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

DWIIS_DOCKER_COMPOSE_DIR="${DWIIS_DOCKER_COMPOSE_DIR:-/etc/dwiis/docker}"
DWIIS_DOCKER_COMPOSE_FILE="${DWIIS_DOCKER_COMPOSE_DIR}/dev-services.compose.yml"
DWIIS_DOCKER_PORTS_ENV="${DWIIS_DOCKER_COMPOSE_DIR}/ports.env"

dwiis_load_docker_ports() {
  if [[ -f "${DWIIS_DOCKER_PORTS_ENV}" ]]; then
    # shellcheck source=/dev/null
    source "${DWIIS_DOCKER_PORTS_ENV}"
  fi
}

dwiis_docker_compose_file() {
  echo "${DWIIS_DOCKER_COMPOSE_FILE}"
}

dwiis_docker_service_running() {
  local service="$1"
  local container="dwiis-${service}"

  if ! command -v docker >/dev/null 2>&1; then
    return 1
  fi

  if ! systemctl is-active --quiet docker 2>/dev/null; then
    return 1
  fi

  if docker inspect -f '{{.State.Running}}' "${container}" 2>/dev/null | grep -qx true; then
    return 0
  fi
  return 1
}

dwiis_docker_service_healthy() {
  local service="$1"
  local container="dwiis-${service}"
  local status

  if ! dwiis_docker_service_running "${service}"; then
    return 1
  fi

  status="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "${container}" 2>/dev/null || echo missing)"
  [[ "${status}" == "healthy" || "${status}" == "none" ]]
}

dwiis_docker_cli_wrapper_ok() {
  local binary="$1"
  command -v "${binary}" >/dev/null 2>&1
}

dwiis_ensure_docker_dev_services() {
  if [[ ! -f "${DWIIS_DOCKER_COMPOSE_FILE}" ]]; then
    return 1
  fi
  docker compose -f "${DWIIS_DOCKER_COMPOSE_FILE}" up -d >/dev/null 2>&1 || return 1
  return 0
}
