#!/usr/bin/env bash
# shellcheck shell=bash
# Resolve DWIIS repository root. Source from scripts/*.sh before other libs.

if [[ -n "${DWIIS_REPO_ROOT:-}" && -d "${DWIIS_REPO_ROOT}/scripts" ]]; then
  REPO_ROOT="${DWIIS_REPO_ROOT}"
else
  _dwiis_caller_dir="$(cd "$(dirname "${BASH_SOURCE[1]}")" && pwd)"
  REPO_ROOT="$(cd "${_dwiis_caller_dir}/.." && pwd)"
fi
export DWIIS_REPO_ROOT="${REPO_ROOT}"
unset _dwiis_caller_dir
