#!/usr/bin/env bash
# shellcheck shell=bash
# Structured logging with timestamps, hostname, and user context.

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

DWIIS_LOG_FILE="${DWIIS_LOG_FILE:-}"

dwiis_init_logging() {
  local session_id
  session_id="$(date +%Y%m%d-%H%M%S)-$$"
  dwiis_ensure_dirs
  DWIIS_LOG_FILE="${DWIIS_LOG_DIR}/install-${session_id}.log"
  sudo touch "${DWIIS_LOG_FILE}"
  sudo chmod 644 "${DWIIS_LOG_FILE}"
  # Symlink latest log for convenience
  sudo ln -sfn "${DWIIS_LOG_FILE}" "${DWIIS_LOG_DIR}/latest.log"
}

dwiis_log() {
  local level="$1"
  shift
  local msg="$*"
  local ts host user
  ts="$(date -Iseconds)"
  host="$(hostname -s 2>/dev/null || echo unknown)"
  user="$(id -un 2>/dev/null || echo unknown)"
  local line="[${ts}] [${level}] [${host}/${user}] ${msg}"
  if [[ -n "${DWIIS_LOG_FILE}" ]]; then
    echo "${line}" | sudo tee -a "${DWIIS_LOG_FILE}" >/dev/null
  fi
  case "${level}" in
    ERROR) echo "${line}" >&2 ;;
    *) echo "${line}" ;;
  esac
}

dwiis_log_info()  { dwiis_log "INFO" "$@"; }
dwiis_log_warn()  { dwiis_log "WARN" "$@"; }
dwiis_log_error() { dwiis_log "ERROR" "$@"; }
dwiis_log_debug() {
  if [[ "${DWIIS_DEBUG:-0}" == "1" ]]; then
    dwiis_log "DEBUG" "$@"
  fi
}
