#!/usr/bin/env bash
# shellcheck shell=bash
# Shared constants and helpers for the DWIIS platform (Dedusoft).

# Safe to source multiple times — install.sh loads several libs that each import common.
if [[ -n "${_DWIIS_COMMON_SH_LOADED:-}" ]]; then
  [[ "${BASH_SOURCE[0]}" != "${0}" ]] && return 0
  exit 0
fi
_DWIIS_COMMON_SH_LOADED=1

set -euo pipefail

# Platform identity (use plain vars — readonly breaks when libs re-source this file)
: "${DWIIS_PLATFORM_NAME:=dwiis}"
: "${DWIIS_STATE_DIR:=/var/lib/dwiis/state}"
: "${DWIIS_LOG_DIR:=/var/log/dwiis}"
: "${DWIIS_BACKUP_DIR:=/var/lib/dwiis/backups}"
: "${DWIIS_CACHE_DIR:=/var/lib/dwiis/cache}"
: "${DWIIS_INSTALL_ROOT:=/opt/dwiis}"
: "${DWIIS_CONFIG_DIR:=/etc/dwiis}"
: "${DWIIS_REPORT_DIR:=/var/lib/dwiis/reports}"
: "${DWIIS_RETRY_MAX:=5}"
: "${DWIIS_RETRY_BASE_DELAY:=2}"

# Supported Ubuntu LTS releases
if [[ -z "${DWIIS_SUPPORTED_UBUNTU_VERSIONS+x}" ]]; then
  DWIIS_SUPPORTED_UBUNTU_VERSIONS=("22.04" "24.04" "26.04")
fi

export DWIIS_PLATFORM_NAME DWIIS_STATE_DIR DWIIS_LOG_DIR DWIIS_BACKUP_DIR
export DWIIS_CACHE_DIR DWIIS_INSTALL_ROOT DWIIS_CONFIG_DIR DWIIS_REPORT_DIR
export DWIIS_RETRY_MAX DWIIS_RETRY_BASE_DELAY

# Resolve repository root (development vs installed layout)
dwiis_repo_root() {
  if [[ -n "${DWIIS_REPO_ROOT:-}" ]]; then
    echo "${DWIIS_REPO_ROOT}"
    return 0
  fi
  if [[ -d "${DWIIS_INSTALL_ROOT}/ansible" ]]; then
    echo "${DWIIS_INSTALL_ROOT}"
    return 0
  fi
  local script_dir
  script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
  echo "${script_dir}"
}

dwiis_ensure_dirs() {
  local dirs=(
    "${DWIIS_STATE_DIR}"
    "${DWIIS_LOG_DIR}"
    "${DWIIS_BACKUP_DIR}"
    "${DWIIS_CACHE_DIR}"
    "${DWIIS_REPORT_DIR}"
    "${DWIIS_CONFIG_DIR}"
  )
  local owner="${SUDO_USER:-${USER:-$(id -un)}}"
  for d in "${dirs[@]}"; do
    if [[ ! -d "${d}" ]]; then
      sudo mkdir -p "${d}"
    fi
    sudo chown "${owner}:${owner}" "${d}" 2>/dev/null || true
    sudo chmod 755 "${d}"
  done
}

dwiis_detect_os() {
  if [[ ! -f /etc/os-release ]]; then
    echo "unknown"
    return 1
  fi
  # shellcheck source=/dev/null
  source /etc/os-release
  echo "${ID:-unknown}:${VERSION_ID:-unknown}"
}

dwiis_is_supported_ubuntu() {
  local os_info version
  os_info="$(dwiis_detect_os 2>/dev/null || echo unknown:unknown)"
  local id="${os_info%%:*}"
  local ver="${os_info##*:}"
  if [[ "${id}" != "ubuntu" ]]; then
    return 1
  fi
  for v in "${DWIIS_SUPPORTED_UBUNTU_VERSIONS[@]}"; do
    if [[ "${ver}" == "${v}" ]]; then
      return 0
    fi
  done
  return 1
}

dwiis_has_internet() {
  if curl -fsSL --max-time 5 --head "https://dwiis.dedusoft.com" >/dev/null 2>&1; then
    return 0
  fi
  if curl -fsSL --max-time 5 --head "https://archive.ubuntu.com" >/dev/null 2>&1; then
    return 0
  fi
  return 1
}

dwiis_sha256_file() {
  local file="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "${file}" | awk '{print $1}'
  else
    shasum -a 256 "${file}" | awk '{print $1}'
  fi
}

dwiis_verify_checksum() {
  local file="$1"
  local expected="$2"
  local actual
  actual="$(dwiis_sha256_file "${file}")"
  if [[ "${actual}" != "${expected}" ]]; then
    echo "Checksum mismatch for ${file}: expected ${expected}, got ${actual}" >&2
    return 1
  fi
  return 0
}

dwiis_run_as_user() {
  local user="$1"
  shift
  if [[ "$(id -un)" == "${user}" ]]; then
    "$@"
  else
    sudo -u "${user}" -H bash -lc "$(printf '%q ' "$@")"
  fi
}
