#!/usr/bin/env bash
# shellcheck shell=bash
# Offline cache support for packages and artifacts.

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

DWIIS_CACHE_DEB_DIR="${DWIIS_CACHE_DIR}/debs"
DWIIS_CACHE_ARTIFACTS_DIR="${DWIIS_CACHE_DIR}/artifacts"
DWIIS_CACHE_APT_DIR="${DWIIS_CACHE_DIR}/apt"
DWIIS_INTERNAL_MIRROR="${DWIIS_INTERNAL_MIRROR:-}"

dwiis_cache_init() {
  dwiis_ensure_dirs
  sudo mkdir -p "${DWIIS_CACHE_DEB_DIR}" "${DWIIS_CACHE_ARTIFACTS_DIR}" "${DWIIS_CACHE_APT_DIR}"
}

dwiis_cache_artifact_path() {
  local name="$1"
  echo "${DWIIS_CACHE_ARTIFACTS_DIR}/${name}"
}

dwiis_cache_get_or_download() {
  local url="$1"
  local name="$2"
  local checksum="${3:-}"

  dwiis_cache_init
  local cached
  cached="$(dwiis_cache_artifact_path "${name}")"

  if [[ -f "${cached}" ]]; then
    if [[ -n "${checksum}" ]]; then
      if dwiis_verify_checksum "${cached}" "${checksum}"; then
        dwiis_log_info "Using cached artifact: ${name}"
        echo "${cached}"
        return 0
      fi
      dwiis_log_warn "Cached artifact checksum mismatch, re-downloading: ${name}"
    else
      dwiis_log_info "Using cached artifact (no checksum): ${name}"
      echo "${cached}"
      return 0
    fi
  fi

  if ! dwiis_has_internet; then
    dwiis_log_error "No network and no valid cache for: ${name}"
    return 1
  fi

  # shellcheck source=scripts/lib/retry.sh
  source "$(dirname "${BASH_SOURCE[0]}")/retry.sh"
  dwiis_retry_download "${url}" "${cached}" "${checksum}"
  echo "${cached}"
}

dwiis_apt_install_with_cache() {
  local pkg="$1"
  dwiis_cache_init

  local deb
  deb="${DWIIS_CACHE_DEB_DIR}/${pkg}.deb"
  if [[ -f "${deb}" ]]; then
    dwiis_log_info "Installing ${pkg} from local cache"
  # shellcheck source=scripts/lib/retry.sh
    source "$(dirname "${BASH_SOURCE[0]}")/retry.sh"
    dwiis_retry "${DWIIS_RETRY_MAX}" sudo dpkg -i "${deb}" || sudo apt-get install -f -y
    return 0
  fi

  if [[ -n "${DWIIS_INTERNAL_MIRROR}" ]]; then
    dwiis_log_info "Using internal apt mirror: ${DWIIS_INTERNAL_MIRROR}"
    sudo sed -i "s|http://archive.ubuntu.com/ubuntu|${DWIIS_INTERNAL_MIRROR}|g" /etc/apt/sources.list 2>/dev/null || true
  fi

  # shellcheck source=scripts/lib/retry.sh
  source "$(dirname "${BASH_SOURCE[0]}")/retry.sh"
  dwiis_retry_apt_install "${pkg}"
}

dwiis_populate_cache_from_manifest() {
  local manifest="$1"
  if [[ ! -f "${manifest}" ]]; then
    dwiis_log_warn "Cache manifest not found: ${manifest}"
    return 0
  fi

  while IFS='|' read -r name url checksum; do
    [[ -z "${name}" || "${name}" == \#* ]] && continue
    dwiis_cache_get_or_download "${url}" "${name}" "${checksum}" >/dev/null || true
  done < "${manifest}"
}
