#!/usr/bin/env bash
# shellcheck shell=bash
# Resolve free localhost ports for Docker dev services when defaults are taken.

set -euo pipefail

PORTS_ENV_FILE=""
PORTS_YAML_FILE=""
MAX_OFFSET=100
SERVICES=()

declare -A DEFAULT_PORTS=(
  [postgres]=5432
  [mysql]=3306
  [mongodb]=27017
  [redis]=6379
  [adminer]=8080
)

usage() {
  cat <<EOF
Usage: resolve-ports.sh [--ports-env PATH] [--ports-yaml PATH] [--max-offset N] -- SERVICE [SERVICE...]

Services: postgres mysql mongodb redis adminer
EOF
}

log_info() {
  echo "[resolve-ports] $*" >&2
}

port_in_use() {
  local port="$1"
  ss -H -tln "sport = :${port}" 2>/dev/null | grep -q .
}

container_host_port() {
  local service="$1"
  local internal_port="$2"
  docker port "dwiis-${service}" "${internal_port}/tcp" 2>/dev/null | head -1 | sed 's/.*://'
}

saved_port() {
  local var_name="$1"
  if [[ -f "${PORTS_ENV_FILE}" ]]; then
    grep -E "^${var_name}=" "${PORTS_ENV_FILE}" 2>/dev/null | head -1 | cut -d= -f2-
  fi
}

port_usable() {
  local service="$1"
  local host_port="$2"
  local internal_port="$3"
  local mapped

  if ! port_in_use "${host_port}"; then
    return 0
  fi

  mapped="$(container_host_port "${service}" "${internal_port}" 2>/dev/null || true)"
  [[ -n "${mapped}" && "${mapped}" == "${host_port}" ]]
}

resolve_port() {
  local service="$1"
  local default_port="${DEFAULT_PORTS[${service}]:-}"
  local var_name internal_port mapped saved port end

  if [[ -z "${default_port}" ]]; then
    log_info "Unknown service: ${service}"
    return 1
  fi

  internal_port="${default_port}"
  var_name="$(echo "${service}" | tr '[:lower:]' '[:upper:]')_PORT"

  mapped="$(container_host_port "${service}" "${internal_port}" 2>/dev/null || true)"
  if [[ -n "${mapped}" ]]; then
    RESOLVED_PORT="${mapped}"
    return 0
  fi

  saved="$(saved_port "${var_name}")"
  if [[ -n "${saved}" ]] && port_usable "${service}" "${saved}" "${internal_port}"; then
    RESOLVED_PORT="${saved}"
    return 0
  fi

  port="${default_port}"
  end=$((default_port + MAX_OFFSET))
  while [[ "${port}" -lt "${end}" ]]; do
    if port_usable "${service}" "${port}" "${internal_port}"; then
      if [[ "${port}" != "${default_port}" ]]; then
        log_info "${service}: port ${default_port} in use, using ${port}"
      fi
      RESOLVED_PORT="${port}"
      return 0
    fi
    port=$((port + 1))
  done

  log_info "No free port for ${service} in range ${default_port}-$((end - 1))"
  return 1
}

write_ports_files() {
  local service port var_name

  if [[ -n "${PORTS_ENV_FILE}" ]]; then
    mkdir -p "$(dirname "${PORTS_ENV_FILE}")"
    : > "${PORTS_ENV_FILE}.tmp"
    for service in "${!RESOLVED_PORTS[@]}"; do
      port="${RESOLVED_PORTS[${service}]}"
      var_name="$(echo "${service}" | tr '[:lower:]' '[:upper:]')_PORT"
      echo "${var_name}=${port}" >> "${PORTS_ENV_FILE}.tmp"
    done
    mv "${PORTS_ENV_FILE}.tmp" "${PORTS_ENV_FILE}"
  fi

  if [[ -n "${PORTS_YAML_FILE}" ]]; then
    mkdir -p "$(dirname "${PORTS_YAML_FILE}")"
    {
      echo "---"
      for service in "${!RESOLVED_PORTS[@]}"; do
        echo "${service}: ${RESOLVED_PORTS[${service}]}"
      done
    } > "${PORTS_YAML_FILE}.tmp"
    mv "${PORTS_YAML_FILE}.tmp" "${PORTS_YAML_FILE}"
  fi
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --ports-env)
        PORTS_ENV_FILE="$2"
        shift 2
        ;;
      --ports-yaml)
        PORTS_YAML_FILE="$2"
        shift 2
        ;;
      --max-offset)
        MAX_OFFSET="$2"
        shift 2
        ;;
      --)
        shift
        SERVICES=("$@")
        return 0
        ;;
      -h|--help)
        usage
        exit 0
        ;;
      *)
        SERVICES+=("$1")
        shift
        ;;
    esac
  done
}

declare -A RESOLVED_PORTS=()

main() {
  parse_args "$@"

  if [[ "${#SERVICES[@]}" -eq 0 ]]; then
    usage >&2
    exit 1
  fi

  local service
  for service in "${SERVICES[@]}"; do
    resolve_port "${service}"
    RESOLVED_PORTS["${service}"]="${RESOLVED_PORT}"
  done

  write_ports_files

  for service in "${SERVICES[@]}"; do
    echo "${service}=${RESOLVED_PORTS[${service}]}"
  done
}

main "$@"
