#!/usr/bin/env bash
# shellcheck shell=bash
# Exponential backoff retry for transient failures.

if [[ -n "${_DWIIS_RETRY_SH_LOADED:-}" ]]; then
  [[ "${BASH_SOURCE[0]}" != "${0}" ]] && return 0
  exit 0
fi
_DWIIS_RETRY_SH_LOADED=1

set -euo pipefail

# shellcheck source=scripts/lib/common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "$(dirname "${BASH_SOURCE[0]}")/logging.sh"

# Transient exit codes (network, lock, temporary apt failures)
if [[ -z "${DWIIS_TRANSIENT_PATTERNS+x}" ]]; then
  DWIIS_TRANSIENT_PATTERNS=(
    "Could not get lock"
    "Temporary failure"
    "Connection timed out"
    "Connection reset"
    "Network is unreachable"
    "Failed to fetch"
    "TLS handshake"
    "Resource temporarily unavailable"
  )
fi

dwiis_is_transient_output() {
  local output="$1"
  local pattern
  for pattern in "${DWIIS_TRANSIENT_PATTERNS[@]}"; do
    if [[ "${output}" == *"${pattern}"* ]]; then
      return 0
    fi
  done
  return 1
}

dwiis_retry() {
  local max="${1:-${DWIIS_RETRY_MAX}}"
  shift
  local attempt=1
  local delay="${DWIIS_RETRY_BASE_DELAY}"
  local output
  local rc

  while [[ "${attempt}" -le "${max}" ]]; do
    set +e
    output="$("$@" 2>&1)"
    rc=$?
    set -e

    if [[ "${rc}" -eq 0 ]]; then
      [[ -n "${output}" ]] && echo "${output}"
      return 0
    fi

    if dwiis_is_transient_output "${output}" || [[ "${rc}" -eq 124 ]]; then
      dwiis_log_warn "Transient failure (attempt ${attempt}/${max}): $* — retrying in ${delay}s"
      dwiis_log_debug "${output}"
      sleep "${delay}"
      delay=$((delay * 2))
      attempt=$((attempt + 1))
    else
      dwiis_log_error "Non-transient failure: $*"
      echo "${output}" >&2
      return "${rc}"
    fi
  done

  dwiis_log_error "Retry limit exceeded for: $*"
  echo "${output}" >&2
  return 1
}

dwiis_repair_apt_conflicts() {
  local log_file
  log_file="$(mktemp)"

  if sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y >"${log_file}" 2>&1; then
    rm -f "${log_file}"
    return 0
  fi

  if grep -Eqi 'Conflicting values set for option Signed-By|The list of sources could not be read|NO_PUBKEY|The following signatures could not be verified' "${log_file}"; then
    dwiis_log_warn "Detected broken apt repository signatures; repairing managed tool sources"
    sudo rm -f \
      /etc/apt/sources.list.d/vscode.list \
      /etc/apt/sources.list.d/code.list \
      /etc/apt/sources.list.d/microsoft*.list \
      /etc/apt/sources.list.d/google-chrome.list \
      /etc/apt/keyrings/microsoft-vscode.asc \
      /etc/apt/keyrings/packages.microsoft.gpg \
      /etc/apt/keyrings/google-chrome.asc \
      /etc/apt/keyrings/*microsoft*.gpg
    sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y >"${log_file}" 2>&1
  fi

  if [[ $? -eq 0 ]]; then
    rm -f "${log_file}"
    return 0
  fi

  cat "${log_file}" >&2
  rm -f "${log_file}"
  return 1
}

dwiis_retry_apt_update() {
  local output rc
  set +e
  output="$(sudo env DEBIAN_FRONTEND=noninteractive apt-get update -y 2>&1)"
  rc=$?
  set -e

  if [[ "${rc}" -eq 0 ]]; then
    echo "${output}"
    return 0
  fi

  if echo "${output}" | grep -Eqi 'Conflicting values set for option Signed-By|The list of sources could not be read|NO_PUBKEY|The following signatures could not be verified'; then
    dwiis_repair_apt_conflicts
    return $?
  fi

  echo "${output}" >&2
  return "${rc}"
}

dwiis_retry_apt_install() {
  local output rc
  set +e
  output="$(sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@" 2>&1)"
  rc=$?
  set -e

  if [[ "${rc}" -eq 0 ]]; then
    echo "${output}"
    return 0
  fi

  if echo "${output}" | grep -Eqi 'Conflicting values set for option Signed-By|The list of sources could not be read|NO_PUBKEY|The following signatures could not be verified'; then
    dwiis_repair_apt_conflicts
    if ! sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; then
      echo "${output}" >&2
      return 1
    fi
    return 0
  fi

  echo "${output}" >&2
  return "${rc}"
}

dwiis_retry_download() {
  local url="$1"
  local dest="$2"
  local checksum="${3:-}"

  dwiis_retry "${DWIIS_RETRY_MAX}" curl -fsSL --retry 3 --retry-delay 2 -o "${dest}.part" "${url}"
  mv "${dest}.part" "${dest}"

  if [[ -n "${checksum}" ]]; then
    dwiis_verify_checksum "${dest}" "${checksum}"
  fi
}

dwiis_retry_git_clone() {
  local url="$1"
  local dest="$2"
  local branch="${3:-}"

  if [[ -d "${dest}/.git" ]]; then
    dwiis_log_info "Git repo already exists at ${dest}, fetching updates"
    dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${dest}" fetch --all --prune
    if [[ -n "${branch}" ]]; then
      dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${dest}" checkout "${branch}"
      dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${dest}" pull --ff-only
    fi
    return 0
  fi

  local args=(-fsSL)
  if [[ -n "${branch}" ]]; then
    args+=(-b "${branch}")
  fi
  dwiis_retry "${DWIIS_RETRY_MAX}" git clone "${args[@]}" "${url}" "${dest}"
}
