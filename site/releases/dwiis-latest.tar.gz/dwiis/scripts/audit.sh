#!/usr/bin/env bash
# shellcheck shell=bash
# Drift detection — compare workstation against approved standards.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/repo-root.sh
source "${SCRIPT_DIR}/lib/repo-root.sh"

# shellcheck source=scripts/lib/common.sh
source "${REPO_ROOT}/scripts/lib/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "${REPO_ROOT}/scripts/lib/logging.sh"
# shellcheck source=scripts/lib/state.sh
source "${REPO_ROOT}/scripts/lib/state.sh"
# shellcheck source=scripts/lib/docker-services.sh
source "${REPO_ROOT}/scripts/lib/docker-services.sh"

if [[ -f "${DWIIS_CONFIG_DIR}/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${DWIIS_CONFIG_DIR}/platform.env"
elif [[ -f "${REPO_ROOT}/configs/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${REPO_ROOT}/configs/platform.env"
fi

DWIIS_DRIFT_ISSUES=()
DWIIS_REMEDIATE="${DWIIS_REMEDIATE:-0}"

dwiis_drift_record() {
  local severity="$1"
  local category="$2"
  local message="$3"
  DWIIS_DRIFT_ISSUES+=("${severity}|${category}|${message}")
}

dwiis_audit_packages() {
  local profile
  profile="$(dwiis_get_profile)"
  local profile_file="${REPO_ROOT}/configs/profiles/${profile}.yaml"
  [[ ! -f "${profile_file}" ]] && profile_file="${REPO_ROOT}/configs/profiles/full.yaml"

  local pkgs
  pkgs="$(grep -A 100 'apt:' "${profile_file}" | grep '    - ' | sed 's/    - //' | grep -v '^roles' || true)"
  while IFS= read -r pkg; do
    [[ -z "${pkg}" ]] && continue
    if ! dpkg -s "${pkg}" >/dev/null 2>&1; then
      dwiis_drift_record "HIGH" "package" "Missing apt package: ${pkg}"
      if [[ "${DWIIS_REMEDIATE}" == "1" ]]; then
        # shellcheck source=scripts/lib/retry.sh
        source "${REPO_ROOT}/scripts/lib/retry.sh"
        dwiis_retry_apt_install "${pkg}" || true
      fi
    fi
  done <<< "${pkgs}"
}

dwiis_audit_config_hash() {
  local name="$1"
  local managed="$2"
  local user_home
  user_home="$(getent passwd "${SUDO_USER:-${USER}}" | cut -d: -f6)"
  local target="${user_home}/${managed}"

  local canonical="${REPO_ROOT}/configs/${name}"
  if [[ ! -f "${canonical}" && ! -f "${canonical}.j2" ]]; then
    return 0
  fi

  if [[ ! -f "${target}" ]]; then
    dwiis_drift_record "MEDIUM" "config" "Missing managed config: ${target}"
    return 0
  fi

  if [[ -f "${REPO_ROOT}/configs/.checksums/${name}.sha256" ]]; then
    local expected actual
    expected="$(cat "${REPO_ROOT}/configs/.checksums/${name}.sha256")"
    actual="$(dwiis_sha256_file "${target}")"
    if [[ "${expected}" != "${actual}" ]]; then
      dwiis_drift_record "MEDIUM" "config" "Config drift detected: ${target} (hash mismatch)"
    fi
  fi
}

dwiis_audit_docker_services() {
  local profile_file="${REPO_ROOT}/configs/profiles/$(dwiis_get_profile).yaml"
  [[ ! -f "${profile_file}" ]] && return 0

  if ! grep -q '^docker_services:' "${profile_file}" 2>/dev/null; then
    return 0
  fi

  local services
  services="$(grep -A 50 '^docker_services:' "${profile_file}" | grep '  - ' | sed 's/  - //' || true)"
  while IFS= read -r svc; do
    [[ -z "${svc}" ]] && continue
    [[ "${svc}" == "adminer" ]] && continue

    if ! dwiis_docker_service_running "${svc}"; then
      dwiis_drift_record "HIGH" "docker" "Dev service not running: dwiis-${svc}"
      if [[ "${DWIIS_REMEDIATE}" == "1" ]]; then
        dwiis_ensure_docker_dev_services || true
      fi
      continue
    fi

    if ! dwiis_docker_service_healthy "${svc}"; then
      dwiis_drift_record "MEDIUM" "docker" "Dev service unhealthy: dwiis-${svc}"
    fi
  done <<< "${services}"

  local svc binary
  while IFS= read -r svc; do
    [[ -z "${svc}" ]] && continue
    case "${svc}" in
      postgres) binary=psql ;;
      mysql) binary=mysql ;;
      mongodb) binary=mongosh ;;
      redis) binary=redis-cli ;;
      adminer) continue ;;
      *) continue ;;
    esac
    if ! dwiis_docker_cli_wrapper_ok "${binary}"; then
      dwiis_drift_record "HIGH" "cli" "Missing CLI wrapper on PATH: ${binary}"
    fi
  done <<< "${services}"
}

dwiis_audit_services() {
  local profile
  profile="$(dwiis_get_profile)"
  if grep -q docker "${REPO_ROOT}/configs/profiles/${profile}.yaml" 2>/dev/null; then
    if ! systemctl is-enabled docker >/dev/null 2>&1; then
      dwiis_drift_record "HIGH" "service" "Docker service not enabled"
    fi
    if ! systemctl is-active docker >/dev/null 2>&1; then
      dwiis_drift_record "HIGH" "service" "Docker service not running"
      if [[ "${DWIIS_REMEDIATE}" == "1" ]]; then
        sudo systemctl enable --now docker || true
      fi
    fi

    if grep -q docker_services "${REPO_ROOT}/configs/profiles/${profile}.yaml" 2>/dev/null; then
      if ! systemctl is-enabled dwiis-dev-services >/dev/null 2>&1; then
        dwiis_drift_record "MEDIUM" "service" "dwiis-dev-services not enabled"
      fi
      if ! systemctl is-active dwiis-dev-services >/dev/null 2>&1; then
        dwiis_drift_record "HIGH" "service" "dwiis-dev-services not active"
        if [[ "${DWIIS_REMEDIATE}" == "1" ]]; then
          sudo systemctl enable --now dwiis-dev-services || true
        fi
      fi
    fi
  fi
}

dwiis_audit_versions() {
  local profile_file="${REPO_ROOT}/configs/profiles/$(dwiis_get_profile).yaml"
  [[ ! -f "${profile_file}" ]] && profile_file="${REPO_ROOT}/configs/profiles/full.yaml"

  if grep -q '  - git' "${profile_file}" 2>/dev/null || grep -q git "${profile_file}"; then
    if command -v git >/dev/null 2>&1; then
      local ver
      ver="$(git --version | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?')"
      if [[ "$(printf '%s\n%s\n' "${DWIIS_GIT_MIN_VERSION:-2.34}" "${ver}" | sort -V | head -1)" != "${DWIIS_GIT_MIN_VERSION:-2.34}" ]]; then
        dwiis_drift_record "LOW" "version" "Git version ${ver} below approved ${DWIIS_GIT_MIN_VERSION:-2.34}"
      fi
    fi
  fi
}

dwiis_audit_print_report() {
  local report="${DWIIS_REPORT_DIR}/audit-$(date +%Y%m%d-%H%M%S).txt"
  dwiis_ensure_dirs

  {
    echo "DWIIS Drift Audit"
    echo "==============================="
    echo "Date: $(date -Iseconds)"
    echo "Host: $(hostname -f)"
    echo "Profile: $(dwiis_get_profile)"
    echo "Remediate mode: ${DWIIS_REMEDIATE}"
    echo ""

    if [[ "${#DWIIS_DRIFT_ISSUES[@]}" -eq 0 ]]; then
      echo "No drift detected. Workstation is compliant."
    else
      printf "%-8s %-12s %s\n" "SEVERITY" "CATEGORY" "ISSUE"
      printf "%-8s %-12s %s\n" "--------" "--------" "-----"
      local row sev cat msg
      for row in "${DWIIS_DRIFT_ISSUES[@]}"; do
        IFS='|' read -r sev cat msg <<< "${row}"
        printf "%-8s %-12s %s\n" "${sev}" "${cat}" "${msg}"
      done
      echo ""
      echo "Total issues: ${#DWIIS_DRIFT_ISSUES[@]}"
      echo ""
      echo "Remediate with: dwiis audit --remediate"
      echo "Or re-run install: dwiis install --profile $(dwiis_get_profile)"
    fi
  } | tee "${report}"

  sudo cp "${report}" "${DWIIS_REPORT_DIR}/latest-audit.txt"
}

main() {
  dwiis_init_logging
  for arg in "$@"; do
    case "${arg}" in
      --remediate) DWIIS_REMEDIATE=1 ;;
    esac
  done

  dwiis_log_info "Starting drift audit (remediate=${DWIIS_REMEDIATE})"
  dwiis_audit_packages
  dwiis_audit_docker_services
  dwiis_audit_config_hash "zsh_aliases.sh" ".config/dwiis/zsh_aliases.sh"
  dwiis_audit_services
  dwiis_audit_versions
  dwiis_audit_print_report

  [[ "${#DWIIS_DRIFT_ISSUES[@]}" -eq 0 ]]
}

main "$@"
