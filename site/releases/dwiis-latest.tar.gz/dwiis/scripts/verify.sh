#!/usr/bin/env bash
# shellcheck shell=bash
# Verification engine — confirms installed tools, versions, services, and configs.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/repo-root.sh
source "${SCRIPT_DIR}/lib/repo-root.sh"

# shellcheck source=scripts/lib/common.sh
source "${REPO_ROOT}/scripts/lib/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "${REPO_ROOT}/scripts/lib/logging.sh"
# shellcheck source=scripts/lib/state.sh
source "${REPO_ROOT}/scripts/lib/state.sh"
# shellcheck source=scripts/lib/docker-services.sh
source "${REPO_ROOT}/scripts/lib/docker-services.sh"

if [[ -f "${DWIIS_CONFIG_DIR}/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${DWIIS_CONFIG_DIR}/platform.env"
elif [[ -f "${REPO_ROOT}/configs/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${REPO_ROOT}/configs/platform.env"
fi

declare -a DWIIS_VERIFY_RESULTS=()
DWIIS_VERIFY_PASSED=0
DWIIS_VERIFY_FAILED=0

dwiis_verify_record() {
  local component="$1"
  local status="$2"
  local detail="${3:-}"
  DWIIS_VERIFY_RESULTS+=("${status}|${component}|${detail}")
  if [[ "${status}" == "PASS" ]]; then
    DWIIS_VERIFY_PASSED=$((DWIIS_VERIFY_PASSED + 1))
  else
    DWIIS_VERIFY_FAILED=$((DWIIS_VERIFY_FAILED + 1))
  fi
}

dwiis_version_gte() {
  local current="$1"
  local required="$2"
  if [[ "$(printf '%s\n%s\n' "${required}" "${current}" | sort -V | head -1)" == "${required}" ]]; then
    return 0
  fi
  return 1
}

dwiis_verify_command() {
  local name="$1"
  local cmd="$2"
  local min_ver="${3:-}"
  local optional="${4:-0}"

  if ! command -v "${cmd}" >/dev/null 2>&1; then
    if [[ "${optional}" == "1" ]]; then
      dwiis_verify_record "${name}" "SKIP" "optional tool not installed"
    else
      dwiis_verify_record "${name}" "FAIL" "not installed"
    fi
    return 1
  fi

  local ver
  ver="$("${cmd}" --version 2>/dev/null | head -1 || echo unknown)"
  if [[ -n "${min_ver}" ]] && ! dwiis_version_gte "$(echo "${ver}" | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1)" "${min_ver}"; then
    dwiis_verify_record "${name}" "FAIL" "version ${ver} < required ${min_ver}"
    return 1
  fi
  dwiis_verify_record "${name}" "PASS" "${ver}"
  return 0
}

dwiis_verify_service() {
  local name="$1"
  local optional="${2:-0}"

  if ! systemctl list-unit-files --type=service "${name}.service" >/dev/null 2>&1; then
    if [[ "${optional}" == "1" ]]; then
      dwiis_verify_record "service:${name}" "SKIP" "service unit not installed"
    else
      dwiis_verify_record "service:${name}" "FAIL" "service unit not installed"
    fi
    return 0
  fi

  if systemctl is-active --quiet "${name}" 2>/dev/null; then
    dwiis_verify_record "service:${name}" "PASS" "active"
  elif [[ "${optional}" == "1" ]]; then
    dwiis_verify_record "service:${name}" "SKIP" "not active"
  else
    dwiis_verify_record "service:${name}" "FAIL" "not active"
  fi
}

dwiis_verify_file() {
  local name="$1"
  local path="$2"
  if [[ -f "${path}" ]]; then
    dwiis_verify_record "file:${name}" "PASS" "${path}"
  else
    dwiis_verify_record "file:${name}" "FAIL" "missing ${path}"
  fi
}

dwiis_verify_nvm() {
  local user="${SUDO_USER:-${USER}}"
  local home
  home="$(getent passwd "${user}" | cut -d: -f6)"
  if [[ -s "${home}/.nvm/nvm.sh" ]]; then
    dwiis_verify_record "nvm" "PASS" "installed for ${user}"
  else
    dwiis_verify_record "nvm" "FAIL" "not installed for ${user}"
  fi
}

dwiis_verify_pyenv() {
  local user="${SUDO_USER:-${USER}}"
  local home
  home="$(getent passwd "${user}" | cut -d: -f6)"
  if [[ -d "${home}/.pyenv" ]]; then
    dwiis_verify_record "pyenv" "PASS" "installed for ${user}"
  else
    dwiis_verify_record "pyenv" "FAIL" "not installed for ${user}"
  fi
}

dwiis_verify_sdkman() {
  local user="${SUDO_USER:-${USER}}"
  local home
  home="$(getent passwd "${user}" | cut -d: -f6)"
  if [[ -s "${home}/.sdkman/bin/sdkman-init.sh" ]]; then
    dwiis_verify_record "sdkman" "PASS" "installed for ${user}"
  else
    dwiis_verify_record "sdkman" "FAIL" "not installed for ${user}"
  fi
}

dwiis_verify_composer() {
  local user="${SUDO_USER:-${USER}}"
  local home
  home="$(getent passwd "${user}" | cut -d: -f6)"
  if [[ -x "${home}/.composer/vendor/bin/composer" ]] || command -v composer >/dev/null 2>&1; then
    local ver
    ver="$(dwiis_run_as_user "${user}" composer --version 2>/dev/null | head -1 || echo unknown)"
    dwiis_verify_record "composer" "PASS" "${ver}"
  else
    dwiis_verify_record "composer" "FAIL" "not installed"
  fi
}

dwiis_verify_vscode() {
  if command -v code >/dev/null 2>&1; then
    local ver
    ver="$(code --version 2>/dev/null | head -1 || echo unknown)"
    dwiis_verify_record "vscode" "PASS" "${ver}"
  else
    dwiis_verify_record "vscode" "FAIL" "not installed"
  fi
}

dwiis_verify_chrome() {
  if command -v google-chrome >/dev/null 2>&1 || command -v google-chrome-stable >/dev/null 2>&1; then
    local ver
    ver="$(google-chrome --version 2>/dev/null || google-chrome-stable --version 2>/dev/null || echo unknown)"
    dwiis_verify_record "chrome" "PASS" "${ver}"
  else
    dwiis_verify_record "chrome" "FAIL" "not installed"
  fi
}

dwiis_verify_docker_cli() {
  local name="$1"
  local binary="$2"
  local service="$3"

  if ! dwiis_docker_cli_wrapper_ok "${binary}"; then
    dwiis_verify_record "${name}" "FAIL" "CLI wrapper ${binary} not on PATH"
    return 1
  fi

  if ! dwiis_docker_service_running "${service}"; then
    dwiis_verify_record "${name}" "FAIL" "container dwiis-${service} not running"
    return 1
  fi

  if ! dwiis_docker_service_healthy "${service}"; then
    dwiis_verify_record "${name}" "FAIL" "container dwiis-${service} not healthy"
    return 1
  fi

  dwiis_verify_record "${name}" "PASS" "docker:${service} via /usr/local/bin/${binary}"
  return 0
}

dwiis_verify_newman() {
  if dwiis_docker_cli_wrapper_ok newman; then
    dwiis_verify_record "newman" "PASS" "docker:postman/newman via /usr/local/bin/newman"
  else
    dwiis_verify_record "newman" "FAIL" "newman CLI wrapper not on PATH"
  fi
}

dwiis_verify_docker_dev_stack() {
  local profile_file="${REPO_ROOT}/configs/profiles/$(dwiis_get_profile).yaml"

  if [[ ! -f "$(dwiis_docker_compose_file)" ]]; then
    return 0
  fi

  dwiis_verify_service "docker"
  dwiis_verify_service "dwiis-dev-services" "1"

  local services
  services="$(awk '
    $0 ~ /^docker_services:/ {in_block=1; next}
    in_block && $0 !~ /^  - / {if ($0 ~ /^[^[:space:]]/) exit}
    in_block && $0 ~ /^  - / {
      sub(/^  - /, "", $0)
      gsub(/^[[:space:]]+|[[:space:]]+$/, "", $0)
      if ($0 != "" && $0 != "adminer") print
    }
  ' "${profile_file}" 2>/dev/null || true)"
  while IFS= read -r svc; do
    [[ -z "${svc}" ]] && continue
    if dwiis_docker_service_running "${svc}"; then
      dwiis_verify_record "docker:${svc}" "PASS" "running"
    else
      dwiis_verify_record "docker:${svc}" "FAIL" "not running"
    fi
  done <<< "${services}"
}

dwiis_verify_profile_tools() {
  local profile
  profile="$(dwiis_get_profile)"
  local profile_file="${REPO_ROOT}/configs/profiles/${profile}.yaml"

  if [[ ! -f "${profile_file}" ]]; then
    dwiis_log_warn "Profile file not found: ${profile_file}, running full checks"
    profile="full"
    profile_file="${REPO_ROOT}/configs/profiles/full.yaml"
  fi

  # Always verify base CLI
  dwiis_verify_command "git" "git" "${DWIIS_GIT_MIN_VERSION:-2.34}"
  dwiis_verify_command "curl" "curl" ""
  dwiis_verify_command "jq" "jq" ""

  # Profile-driven optional tools
  local tools
  tools="$(grep -A 200 '^tools:' "${profile_file}" 2>/dev/null | grep '  - ' | sed 's/  - //' || true)"

  while IFS= read -r tool; do
    [[ -z "${tool}" ]] && continue
    case "${tool}" in
      docker) dwiis_verify_command "docker" "docker" "${DWIIS_DOCKER_MIN_VERSION:-24.0}"; dwiis_verify_service "docker" ;;
      node) dwiis_verify_command "node" "node" "" ;;
      npm) dwiis_verify_command "npm" "npm" "" ;;
      nvm) dwiis_verify_nvm ;;
      python) dwiis_verify_command "python3" "python3" "" ;;
      pyenv) dwiis_verify_pyenv ;;
      php) dwiis_verify_command "php" "php" "" ;;
      composer) dwiis_verify_composer ;;
      java) dwiis_verify_command "java" "java" "" ;;
      sdkman) dwiis_verify_sdkman ;;
      aws_cli) dwiis_verify_command "aws" "aws" "" ;;
      kubectl) dwiis_verify_command "kubectl" "kubectl" "" ;;
      helm) dwiis_verify_command "helm" "helm" "" ;;
      postgres_client) dwiis_verify_docker_cli "postgres_client" "psql" "postgres" ;;
      mysql_client) dwiis_verify_docker_cli "mysql_client" "mysql" "mysql" ;;
      mongodb_client) dwiis_verify_docker_cli "mongodb_client" "mongosh" "mongodb" ;;
      redis_cli) dwiis_verify_docker_cli "redis_cli" "redis-cli" "redis" ;;
      newman) dwiis_verify_newman ;;
      vscode) dwiis_verify_vscode ;;
      chrome) dwiis_verify_chrome ;;
      thunderbird) dwiis_verify_command "thunderbird" "thunderbird" "" "1" ;;
      signal) dwiis_verify_command "signal-desktop" "signal-desktop" "" "1" ;;
    esac
  done <<< "${tools}"

  dwiis_verify_docker_dev_stack

  # Config files
  local user="${SUDO_USER:-${USER}}"
  local home
  home="$(getent passwd "${user}" | cut -d: -f6)"
  dwiis_verify_file "gitconfig" "${home}/.gitconfig"
  dwiis_verify_file "zshrc" "${home}/.zshrc"
}

dwiis_verify_print_report() {
  local report_file="${DWIIS_REPORT_DIR}/verify-$(date +%Y%m%d-%H%M%S).txt"
  dwiis_ensure_dirs

  {
    echo "DWIIS Verification Report"
    echo "========================================"
    echo "Date: $(date -Iseconds)"
    echo "Host: $(hostname -f)"
    echo "User: ${SUDO_USER:-${USER}}"
    echo "Profile: $(dwiis_get_profile)"
    echo ""
    printf "%-8s %-24s %s\n" "STATUS" "COMPONENT" "DETAIL"
    printf "%-8s %-24s %s\n" "------" "---------" "------"
    local row status component detail
    for row in "${DWIIS_VERIFY_RESULTS[@]}"; do
      IFS='|' read -r status component detail <<< "${row}"
      printf "%-8s %-24s %s\n" "${status}" "${component}" "${detail}"
    done
    echo ""
    echo "Summary: ${DWIIS_VERIFY_PASSED} passed, ${DWIIS_VERIFY_FAILED} failed"
  } | tee "${report_file}"

  sudo cp "${report_file}" "${DWIIS_REPORT_DIR}/latest-verify.txt"
  dwiis_log_info "Verification report: ${report_file}"

  if [[ "${DWIIS_VERIFY_FAILED}" -gt 0 ]]; then
    dwiis_log_warn "Verification completed with ${DWIIS_VERIFY_FAILED} issue(s); see ${report_file}"
  else
    dwiis_log_info "Verification completed successfully"
  fi
  return 0
}

main() {
  dwiis_init_logging
  dwiis_log_info "Starting verification"
  dwiis_verify_profile_tools
  dwiis_verify_print_report
}

main "$@"
