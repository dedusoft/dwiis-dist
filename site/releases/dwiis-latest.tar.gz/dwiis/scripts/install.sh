#!/usr/bin/env bash
# shellcheck shell=bash
# Orchestrates Ansible provisioning with checkpoint/resume.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/repo-root.sh
source "${SCRIPT_DIR}/lib/repo-root.sh"

# shellcheck source=scripts/lib/common.sh
source "${REPO_ROOT}/scripts/lib/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "${REPO_ROOT}/scripts/lib/logging.sh"
# shellcheck source=scripts/lib/state.sh
source "${REPO_ROOT}/scripts/lib/state.sh"
# shellcheck source=scripts/lib/backup.sh
source "${REPO_ROOT}/scripts/lib/backup.sh"
# shellcheck source=scripts/lib/retry.sh
source "${REPO_ROOT}/scripts/lib/retry.sh"
# shellcheck source=scripts/lib/cache.sh
source "${REPO_ROOT}/scripts/lib/cache.sh"

DWIIS_PROFILE="${DWIIS_PROFILE:-full}"
DWIIS_SKIP_VERIFY="${DWIIS_SKIP_VERIFY:-0}"

usage() {
  cat <<EOF
Usage: install.sh [--profile PROFILE] [--reset-state] [--skip-verify]

Profiles: minimal, frontend, backend, devops, full (default: full)
EOF
}

parse_args() {
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --profile) DWIIS_PROFILE="$2"; shift 2 ;;
      --reset-state) dwiis_state_reset_all; shift ;;
      --skip-verify) DWIIS_SKIP_VERIFY=1; shift ;;
      -h|--help) usage; exit 0 ;;
      *) dwiis_log_error "Unknown argument: $1"; usage; exit 1 ;;
    esac
  done
}

step_self_update() {
  if ! dwiis_has_internet; then
    dwiis_log_warn "No internet — skipping platform update check"
    return 0
  fi

  local version_before version_after
  version_before="$(cat "${REPO_ROOT}/VERSION" 2>/dev/null || echo unknown)"
  dwiis_log_info "Checking for DWIIS updates (current: ${version_before})"

  if bash "${REPO_ROOT}/scripts/self-update.sh"; then
    version_after="$(cat "${DWIIS_INSTALL_ROOT}/VERSION" 2>/dev/null || echo unknown)"
    if [[ "${version_before}" != "${version_after}" ]]; then
      dwiis_log_info "Updated DWIIS ${version_before} -> ${version_after}"
      dwiis_step_reset "ansible_provision"
      dwiis_step_reset "verify"
    else
      dwiis_log_info "DWIIS is already at the latest version (${version_after})"
    fi
  else
    dwiis_log_warn "Platform update check failed — continuing with ${version_before}"
  fi
}

step_bootstrap_prereqs() {
  local step="bootstrap_prereqs"
  dwiis_step_completed "${step}" && return 0

  dwiis_log_info "Installing bootstrap prerequisites"
  dwiis_retry_apt_update
  dwiis_retry_apt_install ansible python3 python3-pip git curl ca-certificates

  dwiis_log_info "Installing Ansible collections"
  export ANSIBLE_CONFIG="${REPO_ROOT}/ansible/ansible.cfg"
  if ! ansible-galaxy collection install -r "${REPO_ROOT}/ansible/requirements.yml"; then
    dwiis_log_warn "Ansible collection install failed — some GUI roles may not work"
  fi

  dwiis_step_mark_done "${step}"
}

step_populate_cache() {
  local step="populate_cache"
  dwiis_step_completed "${step}" && return 0

  dwiis_log_info "Populating offline cache from manifest"
  dwiis_populate_cache_from_manifest "${REPO_ROOT}/configs/cache-manifest.txt"
  dwiis_step_mark_done "${step}"
}

step_run_ansible() {
  local step="ansible_provision"
  local current_version
  current_version="$(cat "${REPO_ROOT}/VERSION" 2>/dev/null || echo unknown)"

  dwiis_invalidate_provision_if_needed "${DWIIS_PROFILE}" "${current_version}"
  dwiis_step_completed "${step}" && return 0

  dwiis_set_profile "${DWIIS_PROFILE}"
  dwiis_log_info "Running Ansible playbook for profile: ${DWIIS_PROFILE}"

  local ansible_dir="${REPO_ROOT}/ansible"
  local inventory="${ansible_dir}/inventory/local.yml"
  local playbook="${ansible_dir}/playbooks/site.yml"
  local target_user="${SUDO_USER:-${USER}}"
  if [[ "${target_user}" == "root" && -n "${LOGNAME:-}" && "${LOGNAME}" != "root" ]]; then
    target_user="${LOGNAME}"
  fi
  local target_home
  target_home="$(getent passwd "${target_user}" | cut -d: -f6)"

  if [[ ! -d "${ansible_dir}/roles/common" ]]; then
    dwiis_log_error "Invalid DWIIS layout — missing ${ansible_dir}/roles"
    return 1
  fi

  if [[ -z "${target_home}" || ! -d "${target_home}" ]]; then
    dwiis_log_error "Cannot resolve home directory for user ${target_user} (got: ${target_home:-empty})"
    dwiis_log_error "Run as the workstation user: dwiis install --profile ${DWIIS_PROFILE}"
    return 1
  fi

  export ANSIBLE_CONFIG="${ansible_dir}/ansible.cfg"
  export ANSIBLE_ROLES_PATH="${ansible_dir}/roles"
  export ANSIBLE_LOCAL_TEMP="${DWIIS_CACHE_DIR}/ansible-tmp"
  sudo mkdir -p "${ANSIBLE_LOCAL_TEMP}"
  sudo chmod 1777 "${ANSIBLE_LOCAL_TEMP}"

  dwiis_log_info "Ansible config: ${ANSIBLE_CONFIG}"
  dwiis_log_info "Ansible roles:  ${ANSIBLE_ROLES_PATH}"

  if ! ansible-galaxy collection install -r "${ansible_dir}/requirements.yml" 2>/dev/null; then
    dwiis_log_warn "Ansible collection install skipped or failed"
  fi

  if ! ansible-playbook \
    -i "${inventory}" \
    "${playbook}" \
    -e "dwiis_profile=${DWIIS_PROFILE}" \
    -e "dwiis_target_user=${target_user}" \
    -e "dwiis_user_home=${target_home}" \
    -e "dwiis_repo_root=${REPO_ROOT}"; then
    dwiis_step_mark_failed "${step}"
    dwiis_rollback_step "${step}"
    return 1
  fi

  dwiis_step_mark_done "${step}"
  dwiis_set_provisioned_profile "${DWIIS_PROFILE}"
  dwiis_set_provisioned_version "${current_version}"
}

step_verify() {
  local step="verify"
  [[ "${DWIIS_SKIP_VERIFY}" == "1" ]] && return 0
  dwiis_step_completed "${step}" && return 0

  dwiis_log_info "Running verification"
  if bash "${REPO_ROOT}/scripts/verify.sh"; then
    dwiis_log_info "Post-install verification completed"
  else
    dwiis_log_warn "Post-install verification completed with issues; continuing"
  fi
  dwiis_step_mark_done "${step}"
}

main() {
  dwiis_init_logging
  parse_args "$@"

  dwiis_log_info "DWIIS install started (profile=${DWIIS_PROFILE})"

  if ! dwiis_is_supported_ubuntu; then
    dwiis_log_error "Unsupported OS. Requires Ubuntu LTS $(IFS=,; echo "${DWIIS_SUPPORTED_UBUNTU_VERSIONS[*]}")"
    exit 1
  fi

  if dwiis_has_internet; then
    dwiis_log_info "Internet connectivity: OK"
  else
    dwiis_log_warn "No internet — proceeding with offline cache only"
  fi

  step_self_update
  step_bootstrap_prereqs
  step_populate_cache
  step_run_ansible
  step_verify

  dwiis_log_info "Installation completed successfully"
}

main "$@"
