#!/usr/bin/env bash
# shellcheck shell=bash
# Generate Markdown release notes for a DWIIS version.
#
# Usage:
#   release-notes.sh <version> [--audience internal|public] [--release-dir DIR]
#
# "What's changed" comes from the matching "## [X.Y.Z]" section of CHANGELOG.md
# when present, otherwise from commit subjects since the previous v* tag
# (version-bump and merge commits are skipped).
#
#   internal  -> notes for the private source repository (commit links included)
#   public    -> notes for the public distribution repository (install, update,
#                and checksum sections; no links into the private repository)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

VERSION="${1:-}"
shift || true
AUDIENCE="internal"
RELEASE_DIR=""
PUBLIC_URL="${DWIIS_PUBLIC_URL:-https://dwiis.dedusoft.com}"
SOURCE_REPO="${DWIIS_SOURCE_REPO:-dedusoft/dwiis}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --audience) AUDIENCE="$2"; shift 2 ;;
    --release-dir) RELEASE_DIR="$2"; shift 2 ;;
    *) echo "error: unknown option: $1" >&2; exit 1 ;;
  esac
done

[[ "${VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "usage: release-notes.sh <X.Y.Z> [--audience internal|public]" >&2; exit 1; }
TAG="v${VERSION}"

changelog_section() {
  local file="${REPO_ROOT}/CHANGELOG.md"
  [[ -f "${file}" ]] || return 0
  awk -v v="${VERSION}" '
    $0 ~ "^## \\[" v "\\]" { found = 1; next }
    found && /^## \[/ { exit }
    found { print }
  ' "${file}" | sed -e '/./,$!d' | sed -e ':a' -e '/^\n*$/{$d;N;ba' -e '}'
}

previous_tag() {
  local ref="${TAG}"
  git -C "${REPO_ROOT}" rev-parse -q --verify "refs/tags/${TAG}" >/dev/null || ref="HEAD"
  git -C "${REPO_ROOT}" describe --tags --abbrev=0 --match 'v[0-9]*.[0-9]*.[0-9]*' "${ref}^" 2>/dev/null || true
}

commit_changes() {
  local prev range end="${TAG}"
  git -C "${REPO_ROOT}" rev-parse -q --verify "refs/tags/${TAG}" >/dev/null || end="HEAD"
  prev="$(previous_tag)"
  range="${end}"
  [[ -n "${prev}" ]] && range="${prev}..${end}"
  git -C "${REPO_ROOT}" log --no-merges --format='%h%x09%s' "${range}" \
    | while IFS=$'\t' read -r sha subject; do
        # Skip release bookkeeping commits.
        shopt -s nocasematch
        if [[ "${subject}" =~ (bump version|chore\(release\)|patch update|^\.\.\.$) ]]; then
          shopt -u nocasematch
          continue
        fi
        shopt -u nocasematch
        subject="${subject#update: }"
        subject="${subject^}"
        if [[ "${AUDIENCE}" == "internal" ]]; then
          echo "- ${subject} (${sha})"
        else
          echo "- ${subject}"
        fi
      done
}

changes="$(changelog_section)"
[[ -n "${changes}" ]] || changes="$(commit_changes)"
[[ -n "${changes}" ]] || changes="- Maintenance release."

if [[ "${AUDIENCE}" == "public" ]]; then
  cat <<EOF
## What's changed

${changes}

## Install

\`\`\`bash
curl -fsSL ${PUBLIC_URL}/install.sh | bash
dwiis install --profile backend    # minimal | frontend | backend | devops | full
\`\`\`

Verified install (recommended):

\`\`\`bash
curl -fsSL ${PUBLIC_URL}/install.sh -o install.sh
curl -fsSL ${PUBLIC_URL}/install.sh.sha256 -o install.sh.sha256
sha256sum -c install.sh.sha256 && bash install.sh
\`\`\`

## Update an existing workstation

\`\`\`bash
dwiis self-update
dwiis install --profile <your-profile>
\`\`\`

Supported: Ubuntu 22.04, 24.04 and 26.04 LTS.
EOF
  if [[ -n "${RELEASE_DIR}" && -f "${RELEASE_DIR}/SHA256SUMS" ]]; then
    printf '\n## Checksums (SHA-256)\n\n```text\n'
    cat "${RELEASE_DIR}/SHA256SUMS"
    printf '```\n'
  fi
else
  prev="$(previous_tag)"
  cat <<EOF
## What's changed

${changes}

**Public distribution:** [dwiis-dist ${TAG}](https://github.com/dedusoft/dwiis-dist/releases/tag/${TAG}) · ${PUBLIC_URL}
EOF
  if [[ -n "${prev}" ]]; then
    echo ""
    echo "**Full changelog:** https://github.com/${SOURCE_REPO}/compare/${prev}...${TAG}"
  fi
fi
