#!/usr/bin/env bash
# shellcheck shell=bash
# Build DWIIS release artifacts and the public website bundle.
#
# This is the single, environment-agnostic build used by every deployment
# target (AWS EC2, GitHub Pages + Releases, ...). Each environment only decides
# WHERE the output is published — the artifacts themselves are identical.
#
# Output layout (default: ./dist):
#
#   dist/release/                  -> files attached to a release
#     dwiis-<version>.tar.gz
#     dwiis-<version>.tar.gz.sha256
#     dwiis-latest.tar.gz
#     dwiis-latest.tar.gz.sha256
#     install.sh
#     install.sh.sha256
#     VERSION
#     SHA256SUMS
#
#   dist/site/                     -> public website root (https://dwiis.dedusoft.com)
#     index.html
#     install.sh
#     install.sh.sha256
#     VERSION
#     releases/                    -> legacy artifact path, kept for installed clients
#       VERSION
#       dwiis-latest.tar.gz(.sha256)
#       dwiis-<version>.tar.gz(.sha256)
#
# The tarball is reproducible: building the same commit twice yields the same
# SHA-256, so a rebuild (e.g. during rollback) never changes published checksums.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

DEFAULT_ARTIFACT_BASE_URL="https://dwiis.dedusoft.com/releases"

OUT_DIR="${DWIIS_BUILD_OUT_DIR:-${REPO_ROOT}/dist}"
VERSION="${DWIIS_BUILD_VERSION:-}"
ARTIFACT_BASE_URL="${DWIIS_PUBLIC_ARTIFACT_BASE_URL:-${DEFAULT_ARTIFACT_BASE_URL}}"
RELEASES_PAGE_URL="${DWIIS_PUBLIC_RELEASES_PAGE_URL:-}"

# Paths never shipped to public machines (internal/infra/dev-only content).
RELEASE_EXCLUDES=(
  ".git"
  ".github"
  ".vscode"
  ".cursor"
  "dist"
  "reports"
  "knowledge"
  "deploy"
  "docs/deployment"
  "docs/production-deployment.md"
)

usage() {
  cat <<EOF
Usage: build-release.sh [options]

Options:
  --out DIR                 Output directory (default: ./dist)
  --version X.Y.Z           Override version (default: contents of VERSION)
  --artifact-base-url URL   Where clients download release tarballs
                            (default: ${DEFAULT_ARTIFACT_BASE_URL})
  --releases-page-url URL   Optional public "Releases" link on the landing page
  -h, --help                Show this help

Environment equivalents: DWIIS_BUILD_OUT_DIR, DWIIS_BUILD_VERSION,
DWIIS_PUBLIC_ARTIFACT_BASE_URL, DWIIS_PUBLIC_RELEASES_PAGE_URL.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --out) OUT_DIR="$2"; shift 2 ;;
    --version) VERSION="$2"; shift 2 ;;
    --artifact-base-url) ARTIFACT_BASE_URL="$2"; shift 2 ;;
    --releases-page-url) RELEASES_PAGE_URL="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "error: unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

log() { echo "[build] $*"; }
die() { echo "[build] ERROR: $*" >&2; exit 1; }

sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" | awk '{print $1}'
  else
    shasum -a 256 "$1" | awk '{print $1}'
  fi
}

# Write "<hash>  <name>" next to a file (format accepted by `sha256sum -c`).
write_checksum() {
  local file="$1"
  printf '%s  %s\n' "$(sha256_of "${file}")" "$(basename "${file}")" > "${file}.sha256"
}

[[ -f "${REPO_ROOT}/VERSION" ]] || die "VERSION file missing in ${REPO_ROOT}"
if [[ -z "${VERSION}" ]]; then
  VERSION="$(tr -d '[:space:]' < "${REPO_ROOT}/VERSION")"
fi
[[ "${VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || die "invalid version '${VERSION}' (expected MAJOR.MINOR.PATCH)"
ARTIFACT_BASE_URL="${ARTIFACT_BASE_URL%/}"
[[ "${ARTIFACT_BASE_URL}" =~ ^https:// ]] || die "--artifact-base-url must use https"

for tool in tar gzip sed awk sha256sum; do
  command -v "${tool}" >/dev/null 2>&1 || die "required tool not found: ${tool}"
done

# Reproducible timestamps: use the commit time when building from git.
if [[ -z "${SOURCE_DATE_EPOCH:-}" ]]; then
  SOURCE_DATE_EPOCH="$(git -C "${REPO_ROOT}" log -1 --format=%ct 2>/dev/null || date +%s)"
fi
export SOURCE_DATE_EPOCH

ARCHIVE="dwiis-${VERSION}.tar.gz"
WORK="$(mktemp -d)"
trap 'rm -rf "${WORK}"' EXIT

log "Building DWIIS ${VERSION}"
log "Artifact base URL: ${ARTIFACT_BASE_URL}"

# ---------------------------------------------------------------------------
# 1. Stage the platform tree
# ---------------------------------------------------------------------------
tar_excludes=(--anchored)
for path in "${RELEASE_EXCLUDES[@]}"; do
  tar_excludes+=(--exclude "./${path}")
done
mkdir -p "${WORK}/stage/dwiis"
tar -C "${REPO_ROOT}" "${tar_excludes[@]}" -cf - . | tar -C "${WORK}/stage/dwiis" -xf -
printf '%s\n' "${VERSION}" > "${WORK}/stage/dwiis/VERSION"

# Point clients at this environment's artifact location.
inject_artifact_url() {
  local file="$1"
  [[ -f "${file}" ]] || die "expected file missing: ${file}"
  if [[ "${ARTIFACT_BASE_URL}" != "${DEFAULT_ARTIFACT_BASE_URL}" ]]; then
    sed -i "s#${DEFAULT_ARTIFACT_BASE_URL}#${ARTIFACT_BASE_URL}#g" "${file}"
  fi
}
inject_artifact_url "${WORK}/stage/dwiis/bootstrap/install.sh"
inject_artifact_url "${WORK}/stage/dwiis/configs/platform.env.public"
inject_artifact_url "${WORK}/stage/dwiis/scripts/self-update.sh"

# Normalise permissions so the archive does not depend on the builder's umask.
find "${WORK}/stage/dwiis" -type d -exec chmod 755 {} +
find "${WORK}/stage/dwiis" -type f -exec chmod 644 {} +
find "${WORK}/stage/dwiis" -type f \( -name '*.sh' -o -path '*/scripts/dwiis' \) -exec chmod 755 {} +

[[ -x "${WORK}/stage/dwiis/scripts/dwiis" ]] || die "staged tree is missing scripts/dwiis"

# ---------------------------------------------------------------------------
# 2. Reproducible tarball
# ---------------------------------------------------------------------------
tar --sort=name \
    --mtime="@${SOURCE_DATE_EPOCH}" \
    --owner=0 --group=0 --numeric-owner \
    --pax-option=exthdr.name=%d/PaxHeaders/%f,delete=atime,delete=ctime \
    -C "${WORK}/stage" -cf - dwiis \
  | gzip -n -9 > "${WORK}/${ARCHIVE}"

# ---------------------------------------------------------------------------
# 3. Release assets
# ---------------------------------------------------------------------------
REL="${OUT_DIR}/release"
SITE="${OUT_DIR}/site"
rm -rf "${REL}" "${SITE}"
mkdir -p "${REL}" "${SITE}/releases"

cp "${WORK}/${ARCHIVE}" "${REL}/${ARCHIVE}"
cp "${WORK}/${ARCHIVE}" "${REL}/dwiis-latest.tar.gz"
cp "${WORK}/stage/dwiis/bootstrap/install.sh" "${REL}/install.sh"
chmod 644 "${REL}/install.sh"
printf '%s\n' "${VERSION}" > "${REL}/VERSION"

write_checksum "${REL}/${ARCHIVE}"
write_checksum "${REL}/dwiis-latest.tar.gz"
write_checksum "${REL}/install.sh"
(cd "${REL}" && sha256sum "${ARCHIVE}" dwiis-latest.tar.gz install.sh VERSION > SHA256SUMS)

# ---------------------------------------------------------------------------
# 4. Website bundle
# ---------------------------------------------------------------------------
sed "s/__DWIIS_VERSION__/${VERSION}/g" "${REPO_ROOT}/deploy/www/index.html" > "${SITE}/index.html"
if [[ -n "${RELEASES_PAGE_URL}" ]]; then
  sed -i "s#__DWIIS_RELEASES_URL__#${RELEASES_PAGE_URL}#g; /<!--releases-link-->/d; /<!--\/releases-link-->/d" "${SITE}/index.html"
else
  sed -i '/<!--releases-link-->/,/<!--\/releases-link-->/d' "${SITE}/index.html"
fi

cp "${REL}/install.sh" "${REL}/install.sh.sha256" "${REL}/VERSION" "${SITE}/"
cp "${REL}/VERSION" "${SITE}/releases/VERSION"
cp "${REL}/${ARCHIVE}" "${REL}/${ARCHIVE}.sha256" "${SITE}/releases/"
cp "${REL}/dwiis-latest.tar.gz" "${REL}/dwiis-latest.tar.gz.sha256" "${SITE}/releases/"

# ---------------------------------------------------------------------------
# 5. Self-check
# ---------------------------------------------------------------------------
(cd "${REL}" && sha256sum -c --quiet SHA256SUMS) || die "checksum self-check failed"
tar tzf "${REL}/${ARCHIVE}" > "${WORK}/listing.txt"
grep -qx 'dwiis/scripts/dwiis' "${WORK}/listing.txt" || die "archive layout invalid"
if grep -Eq '^dwiis/(\.git|\.github|knowledge|deploy)/' "${WORK}/listing.txt"; then
  die "archive contains excluded internal paths"
fi
grep -q "__DWIIS_" "${SITE}/index.html" && die "unreplaced placeholder in index.html"

log "Release assets: ${REL}"
log "Website bundle: ${SITE}"
log "SHA-256 ${ARCHIVE}: $(sha256_of "${REL}/${ARCHIVE}")"
