#!/usr/bin/env bash
# shellcheck shell=bash
# Self-update — artifact mode (public) or git mode (internal Dedusoft developers).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/repo-root.sh
source "${SCRIPT_DIR}/lib/repo-root.sh"

# shellcheck source=scripts/lib/common.sh
source "${REPO_ROOT}/scripts/lib/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "${REPO_ROOT}/scripts/lib/logging.sh"
# shellcheck source=scripts/lib/retry.sh
source "${REPO_ROOT}/scripts/lib/retry.sh"

if [[ -f "${DWIIS_CONFIG_DIR}/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${DWIIS_CONFIG_DIR}/platform.env"
elif [[ -f "${REPO_ROOT}/configs/platform.env" ]]; then
  # shellcheck source=/dev/null
  source "${REPO_ROOT}/configs/platform.env"
fi

DWIIS_LOCAL_OVERRIDES="${DWIIS_CONFIG_DIR}/local-overrides.env"
DWIIS_DISTRIBUTION_MODE="${DWIIS_DISTRIBUTION_MODE:-artifact}"
DWIIS_ARTIFACT_BASE_URL="${DWIIS_ARTIFACT_BASE_URL:-https://github.com/dedusoft/dwiis-dist/releases/latest/download}"

dwiis_preserve_overrides() {
  if [[ -f "${DWIIS_LOCAL_OVERRIDES}" ]]; then
    dwiis_log_info "Preserving local overrides at ${DWIIS_LOCAL_OVERRIDES}"
  fi
}

dwiis_self_update_git() {
  local repo_url="${DWIIS_REPO_URL:-}"
  local branch="${DWIIS_REPO_BRANCH:-main}"

  if [[ -z "${repo_url}" ]]; then
    dwiis_log_error "DWIIS_REPO_URL not set — configure /etc/dwiis/platform.env for git mode"
    return 1
  fi

  if [[ -d "${REPO_ROOT}/.git" ]]; then
    dwiis_log_info "Pulling latest from ${branch} (git mode)"
    dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${REPO_ROOT}" fetch origin
    dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${REPO_ROOT}" checkout "${branch}"
    dwiis_retry "${DWIIS_RETRY_MAX}" git -C "${REPO_ROOT}" pull --ff-only origin "${branch}"
  else
    dwiis_log_info "Cloning platform repository (git mode)"
    local tmp="${DWIIS_CACHE_DIR}/repo-update"
    sudo mkdir -p "${DWIIS_CACHE_DIR}"
    dwiis_retry_git_clone "${repo_url}" "${tmp}" "${branch}"
    sudo rsync -a "${tmp}/" "${REPO_ROOT}/"
  fi

  if [[ "${REPO_ROOT}" != "${DWIIS_INSTALL_ROOT}" ]] && [[ -d "${DWIIS_INSTALL_ROOT}" ]]; then
    dwiis_log_info "Syncing to ${DWIIS_INSTALL_ROOT}"
    sudo rsync -a --delete \
      --exclude '.git' \
      --exclude 'reports/' \
      "${REPO_ROOT}/" "${DWIIS_INSTALL_ROOT}/"
  fi
}

dwiis_self_update_artifact() {
  local tmp archive install_root="${DWIIS_INSTALL_ROOT}"
  tmp="$(mktemp -d)"
  archive="${tmp}/dwiis-latest.tar.gz"

  dwiis_log_info "Downloading release from ${DWIIS_ARTIFACT_BASE_URL} (artifact mode)"
  dwiis_retry_download "${DWIIS_ARTIFACT_BASE_URL}/dwiis-latest.tar.gz.sha256" "${tmp}/dwiis-latest.tar.gz.sha256" ""
  dwiis_retry_download "${DWIIS_ARTIFACT_BASE_URL}/dwiis-latest.tar.gz" "${archive}" ""

  local expected actual
  expected="$(awk '{print $1}' "${tmp}/dwiis-latest.tar.gz.sha256")"
  actual="$(dwiis_sha256_file "${archive}")"
  if [[ "${expected}" != "${actual}" ]]; then
    dwiis_log_error "Release artifact checksum mismatch"
    rm -rf "${tmp}"
    return 1
  fi

  local version
  version="$(curl -fsSL "${DWIIS_ARTIFACT_BASE_URL}/VERSION" 2>/dev/null || echo unknown)"
  dwiis_log_info "Updating to DWIIS version ${version}"

  sudo mkdir -p "${DWIIS_CACHE_DIR}"
  local staging="${DWIIS_CACHE_DIR}/release-staging"
  sudo rm -rf "${staging}"
  sudo mkdir -p "${staging}"
  sudo tar xzf "${archive}" -C "${staging}"

  if [[ ! -d "${staging}/dwiis/scripts" ]]; then
    dwiis_log_error "Invalid release archive layout"
    rm -rf "${tmp}"
    return 1
  fi

  sudo rsync -a --delete \
    --exclude 'state/' \
    --exclude 'reports/' \
    "${staging}/dwiis/" "${install_root}/"

  sudo install -m 755 "${install_root}/scripts/dwiis" /usr/local/bin/dwiis
  rm -rf "${tmp}"
  sudo rm -rf "${staging}"
  dwiis_log_info "Artifact update applied to ${install_root}"
}

main() {
  dwiis_init_logging
  dwiis_preserve_overrides

  case "${DWIIS_DISTRIBUTION_MODE}" in
    git)
      dwiis_self_update_git
      ;;
    artifact)
      dwiis_self_update_artifact
      ;;
    *)
      dwiis_log_error "Unknown DWIIS_DISTRIBUTION_MODE: ${DWIIS_DISTRIBUTION_MODE}"
      exit 1
      ;;
  esac

  local version_file="${DWIIS_INSTALL_ROOT}/VERSION"
  if [[ -f "${version_file}" ]]; then
    dwiis_log_info "Platform version: $(cat "${version_file}")"
  fi

  dwiis_log_info "Self-update complete. Re-run install to apply changes:"
  dwiis_log_info "  dwiis install --profile $(cat "${DWIIS_STATE_DIR}/profile" 2>/dev/null || echo full)"
}

main "$@"
