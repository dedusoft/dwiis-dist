#!/usr/bin/env bash
# shellcheck shell=bash
# Bump DWIIS version in VERSION file (semver: MAJOR.MINOR.PATCH).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
VERSION_FILE="${REPO_ROOT}/VERSION"

usage() {
  cat <<EOF
Usage: bump-version.sh <major|minor|patch|set> [VERSION]

Examples:
  bump-version.sh patch          # 1.0.1 -> 1.0.2
  bump-version.sh minor          # 1.0.2 -> 1.1.0
  bump-version.sh major          # 1.1.0 -> 2.0.0
  bump-version.sh set 1.2.0      # set explicit version
EOF
}

[[ -f "${VERSION_FILE}" ]] || { echo "error: VERSION file not found" >&2; exit 1; }

current="$(tr -d '[:space:]' < "${VERSION_FILE}")"
IFS='.' read -r major minor patch <<< "${current}"
major="${major:-0}"; minor="${minor:-0}"; patch="${patch:-0}"

cmd="${1:-}"
[[ -n "${cmd}" ]] || { usage; exit 1; }

case "${cmd}" in
  patch) patch=$((patch + 1)) ;;
  minor) minor=$((minor + 1)); patch=0 ;;
  major) major=$((major + 1)); minor=0; patch=0 ;;
  set)
    [[ -n "${2:-}" ]] || { echo "error: version required for set" >&2; exit 1; }
    if [[ ! "${2}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      echo "error: invalid semver (use MAJOR.MINOR.PATCH)" >&2
      exit 1
    fi
    echo "${2}" > "${VERSION_FILE}"
    echo "Version set to ${2}"
    exit 0
    ;;
  *) usage; exit 1 ;;
esac

new_version="${major}.${minor}.${patch}"
echo "${new_version}" > "${VERSION_FILE}"
echo "Version bumped: ${current} -> ${new_version}"
