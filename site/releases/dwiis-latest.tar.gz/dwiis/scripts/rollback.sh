#!/usr/bin/env bash
# shellcheck shell=bash
# Rollback handler — restores backed-up configuration files.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/lib/repo-root.sh
source "${SCRIPT_DIR}/lib/repo-root.sh"

# shellcheck source=scripts/lib/common.sh
source "${REPO_ROOT}/scripts/lib/common.sh"
# shellcheck source=scripts/lib/logging.sh
source "${REPO_ROOT}/scripts/lib/logging.sh"
# shellcheck source=scripts/lib/backup.sh
source "${REPO_ROOT}/scripts/lib/backup.sh"
# shellcheck source=scripts/lib/state.sh
source "${REPO_ROOT}/scripts/lib/state.sh"

usage() {
  cat <<EOF
Usage: rollback.sh [--step STEP] [--last-failed]

  --step STEP       Roll back files from a specific install step
  --last-failed     Roll back files from the last failed step (default)
EOF
}

main() {
  dwiis_init_logging
  local step=""

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --step) step="$2"; shift 2 ;;
      --last-failed) step=""; shift ;;
      -h|--help) usage; exit 0 ;;
      *) dwiis_log_error "Unknown argument: $1"; exit 1 ;;
    esac
  done

  if [[ -n "${step}" ]]; then
    dwiis_rollback_step "${step}"
  else
    dwiis_rollback_last_failed_step
  fi
}

main "$@"
