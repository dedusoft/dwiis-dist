# shellcheck shell=bash
# DWIIS shell aliases (sourced from ~/.zshrc)

alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
alias gs='git status'
alias gd='git diff'
alias gc='git commit'
alias gp='git push'
alias gl='git pull'
alias dc='docker compose'
alias dps='docker ps'
alias k='kubectl'

# Docker dev services (DWIIS)
alias dwiis-db-up='sudo systemctl start dwiis-dev-services'
alias dwiis-db-down='sudo systemctl stop dwiis-dev-services'
alias dwiis-db-status='docker compose -f /etc/dwiis/docker/dev-services.compose.yml ps'

# Platform commands
alias dwiis-audit='dwiis audit'
alias dwiis-verify='dwiis verify'
alias dwiis-update='dwiis self-update'
