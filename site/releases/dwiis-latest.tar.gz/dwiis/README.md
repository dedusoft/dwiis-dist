# dwiis

Production-ready platform for provisioning and maintaining consistent Ubuntu LTS developer workstations across a team of 20+ engineers.

## Quick start

### New machine (remote bootstrap)

```bash
curl -fsSL https://dwiis.dedusoft.com/install.sh | bash

# Then provision a profile (always checks for the latest release):
dwiis install --profile backend
```

### Local / development (Dedusoft engineers — private Git)

```bash
git clone git@github.com:dedusoft/dwiis.git
cd dwiis
sudo cp configs/platform.env /etc/dwiis/platform.env
sudo install -m 755 scripts/dwiis /usr/local/bin/dwiis
dwiis install --profile full
```

> **Public users** install via curl only — they receive release artifacts published to the public [`dedusoft/dwiis-dist`](https://github.com/dedusoft/dwiis-dist/releases) repository, not the private source. See [Versioning & releases](docs/versioning.md).

### Verify installation

```bash
dwiis verify
```

## Profiles

| Profile    | Use case                               |
| ---------- | -------------------------------------- |
| `minimal`  | Base CLI tools and shell only          |
| `frontend` | Node, nvm, Docker, VS Code, Chrome     |
| `backend`  | Python, PHP, Docker databases, DBeaver |
| `devops`   | Docker, AWS CLI, kubectl, Helm, Newman |
| `full`     | All company-standard tools             |

```bash
dwiis install --profile frontend
```

## Docker-backed dev services

Port-based tools (PostgreSQL, MySQL, MongoDB, Redis, Adminer) run in Docker — not as native host services. Docker is installed and started **before** any database containers.

| Service    | Host port       | CLI on PATH        |
| ---------- | --------------- | ------------------ |
| PostgreSQL | 127.0.0.1:5432  | `psql`             |
| MySQL      | 127.0.0.1:3306  | `mysql`            |
| MongoDB    | 127.0.0.1:27017 | `mongosh`, `mongo` |
| Redis      | 127.0.0.1:6379  | `redis-cli`        |
| Adminer    | 127.0.0.1:8080  | browser            |

CLI commands are wrappers in `/usr/local/bin` that `exec` into the running containers. GUI tools (DBeaver) connect via `~/.config/dwiis/docker/connections.env`.

```bash
sudo systemctl status docker
sudo systemctl status dwiis-dev-services
psql -c 'SELECT version();'
```

Newman (Postman CLI) runs via the `postman/newman` Docker image.

## CLI commands

| Command                             | Description                                   |
| ----------------------------------- | --------------------------------------------- |
| `dwiis install [--profile PROFILE]` | Provision workstation (idempotent, resumable) |
| `dwiis verify`                      | Run verification report                       |
| `dwiis audit [--remediate]`         | Detect configuration drift                    |
| `dwiis rollback [--step STEP]`      | Restore backed-up configs                     |
| `dwiis self-update`                 | Update to the latest release (or Git in git mode) |
| `dwiis status`                      | Show profile, steps, and report paths         |

## Design principles (implemented)

| Principle               | Implementation                                                                         |
| ----------------------- | -------------------------------------------------------------------------------------- |
| **Idempotency**         | State checks in `scripts/lib/state.sh`; Ansible `state: present`; skip completed steps |
| **Checkpoint / Resume** | Step state in `/var/lib/dwiis/state/steps.state`                                       |
| **Retry logic**         | Exponential backoff in `scripts/lib/retry.sh` for apt, curl, git                       |
| **Rollback**            | Config backups in `/var/lib/dwiis/backups/` + `dwiis rollback`                         |
| **Verification**        | `scripts/verify.sh` — per-component PASS/FAIL report                                   |
| **Drift detection**     | `scripts/audit.sh` — packages, services, versions, config hashes                       |
| **Offline cache**       | `/var/lib/dwiis/cache/` + `configs/cache-manifest.txt`                                 |
| **Profiles**            | `configs/profiles/*.yaml` + Ansible role conditionals                                  |
| **Security**            | GPG/apt signing, checksum validation, SSH hardening, config backups                    |
| **Self-update**         | `scripts/self-update.sh` preserves `/etc/dwiis/local-overrides.env`                    |

## Directory layout

```text
├── bootstrap/install.sh      # Remote one-liner entrypoint
├── ansible/                  # Ansible playbooks and roles
├── configs/                  # Profiles, platform.env, templates
├── scripts/
│   ├── dwiis   # Main CLI
│   ├── install.sh            # Orchestrator
│   ├── verify.sh             # Verification
│   ├── audit.sh              # Drift detection
│   ├── rollback.sh           # Rollback
│   ├── self-update.sh        # Platform updates
│   └── lib/                  # Shared libraries
├── docs/                     # Detailed documentation
└── reports/                  # Runtime reports (also under /var/lib/...)
```

## Configuration

Copy and customize platform settings:

```bash
sudo cp configs/platform.env /etc/dwiis/platform.env
sudo cp configs/platform.env /etc/dwiis/local-overrides.env  # optional overrides
```

Set your Git repository URL, internal mirrors, and approved versions in `platform.env`.

## Logs and state

| Path                      | Purpose                             |
| ------------------------- | ----------------------------------- |
| `/var/log/dwiis/`         | Timestamped install logs            |
| `/var/lib/dwiis/state/`   | Checkpoint/resume state             |
| `/var/lib/dwiis/backups/` | Rollback manifests and file backups |
| `/var/lib/dwiis/cache/`   | Offline package and artifact cache  |
| `/var/lib/dwiis/reports/` | Verify and audit reports            |

## Supported OS

- Ubuntu 22.04 LTS
- Ubuntu 24.04 LTS
- Ubuntu 26.04 LTS

## Documentation

- [Deployment environments](docs/deployment/README.md) — [GitHub](docs/deployment/github.md) (recommended) · [AWS EC2](docs/deployment/aws-ec2.md)
- [Changelog](CHANGELOG.md)
- [Versioning & releases](docs/versioning.md)
- [Installation guide](docs/installation.md)
- [Operations runbook](docs/operations.md)
- [Security model](docs/security.md)
- [Extending profiles](docs/extending.md)
- [Docker dev services](docs/docker-services.md)

## Ansible dependencies

```bash
cd ansible
ansible-galaxy collection install -r requirements.yml
```

## License

Internal use — customize `configs/platform.env` for your organization.
